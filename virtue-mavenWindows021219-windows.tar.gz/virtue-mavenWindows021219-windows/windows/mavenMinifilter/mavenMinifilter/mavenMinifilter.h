/* Copyright(c) 2019 Siege Technologies, 1105 Floyd Avenue Rome, NY 13440

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files(the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions :

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/
#ifndef MAVEN_FILTER_H

#define MAVEN_FILTER_H

#include "..\..\include\maven.h"
/* defines */


#ifdef __cplusplus
extern "C" {
#endif

/* Typedefs */

	typedef WCHAR MAVEN_EXTENSION[MAVEN_MAX_EXT_LENGTH];

	typedef struct _MAVEN_PROCESS_PERMISSIONS {
		PUNICODE_STRING  pProcessImageName;	/* Image name including path */
		DWORD32	  count;					/* number of times this process requested service */
		DWORD32	  fail;						/* number of times this process request failed */
		MAVEN_EXTENSION extensions[MAVEN_MAX_EXT_ENTRIES]; /* list of file types that this app may access */
	} MAVEN_PROCESS_PERMISSIONS;

	typedef struct _MAVEN_CONFIG_RECORD {
		PUNICODE_STRING  pProcessImageName;
	} MAVEN_CONFIG_RECORD;

	typedef struct _MAVEN_STATE_CHANGE {
		OPERATING_MODE mode;
	} MAVEN_STATE_CHANGE;

#ifdef __cplusplus
}
#endif

#endif /* MAVEN_FILTER_H */
