/* Copyright(c) 2019 Siege Technologies, 1105 Floyd Avenue Rome, NY 13440

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files(the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions :

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

#pragma once

#define TRANSDUCER_FILEFILTER 0
#define TRANSDUCER_NETFILTER 1

#define MAVEN_MAX_EXT_LENGTH 8
#define MAVEN_MAX_EXT_ENTRIES 16
#define MAVEN_NUM_PROC	2048
#define PAYLOAD_MSG_SZ 1024		/* WCHAR must be large enough for max message */
#define MAVEN_LOG_SIZE 64		/* max entries in log buffer */
#define MAX_NETFILTER_CONFIG_SIZE 1024 /* max size of netfilter config file */
#define MAX_USERNAME_LEN 64
#define PACKETDUMP_MSGSIZE 8000 /* max packet dump message size */
#define HEARTBEAT_DELAY 30000	/* ms - every 30 seconds */
#define STATE_TRANSITION_MAX_DLY 5000 /* max for filter to finish state transition (ms) */
#define NETFILTER_STARTUP_TIMEOUT 30	/* max time for netfilter driver to load (sec) */
#define CONSOLE_LINE_SIZE 132	/* max message to console */
#define FILE_BLACKLIST_SIZE 64	/* size of maven filefilter blacklist */

#define INSTANCE_ID_FILE "\\maven\\id.txt"
#define MAVEN_FILEFILTER_CONFIG_FILE_NAME "C:\\maven\\maven.txt"
#define MAVEN_FILEFILTER_CONFIG_FILE_NAME_W L"C:\\maven\\maven.txt"
#define MAVEN_PORT_NAME L"\\MavenFilterPort"	/* file filter driver port name */
#define PERMISSIONS_CONFIG_FILE_FOLDER_NAME_W L"\\DriverTest" /* file filter whitelist folder */
#define PERMISSIONS_CONFIG_FILE_FOLDER_W L"\\??\\C:" PERMISSIONS_CONFIG_FILE_FOLDER_NAME_W
#define PERMISSIONS_CONFIG_FILE_W L"maven.txt" /* file filter whitelist file name */
#define PERMISSIONS_CONFIG_FILE_NAME_W PERMISSIONS_CONFIG_FILE_FOLDER_W L"\\" PERMISSIONS_CONFIG_FILE_W

#define PERMISSIONS_CONFIG_FILE_FOLDER_NAME_ "\\DriverTest" /* file filter whitelist folder */
#define PERMISSIONS_CONFIG_FILE_FOLDER_ "\\??\\C:" PERMISSIONS_CONFIG_FILE_FOLDER_NAME_
#define PERMISSIONS_CONFIG_FILE_ "maven.txt" /* file filter whitelist file name */
#define PERMISSIONS_CONFIG_FILE_NAME_ PERMISSIONS_CONFIG_FILE_FOLDER_ "\\" PERMISSIONS_CONFIG_FILE_


#define MAVEN_HOST_NAME NULL						/* host name of Admin port */
#define MAVEN_PORT_NUMBER "65000"					/* Admin App port name */
#define MAVEN_PORT_NUMBER_BIN 65000					/* Admin App port name */
#define CNC_PORT_NUMBER "65001"						/* C&C port name */
#define CNC_PORT_NUMBER_BIN 65001					/* C&C port name */
#define CNC_NAMED_PIPES								/* used named pipes for C&C */
#define CNC_PIPE_NAME "mavenWindows_pipe"			/* C&C named CnCpipe */
#define MAVEN_ADMIN_PORT_NUMBER "5170"				/* fluentd port number */
#define MAVEN_ADMIN_PORT_NUMBER_BIN 5170			/* fluentd port number binary */
#define MAVEN_ADMIN_HOST_NAME NULL		/* fluentd host name */
#define FILEFILTER_PORT_NUMBER MAVEN_PORT_NUMBER	/* File Filter App port name */
#define NETFILTER_PORT_NUMBER MAVEN_PORT_NUMBER		/* Net Filter App port name */


#define MAVEN_FOLDER "\\??\\C:\\maven\\" 
#define MAVEN_FOLDER_W L"\\??\\C:\\maven\\" 
#define MAVEN_DIRECTORY "\\??\\C:\\maven\\" 
#define MAVEN_DIRECTORY_W L"\\??\\C:\\maven\\" 
#define NET_CONFIG_FILENAME "netconfig.txt"
#define NET_CONFIG_NAME MAVEN_FOLDER NET_CONFIG_FILENAME

#define PKTLOG_FILENAME L"packetLog.txt"
#define NETLOG_FILENAME L"webfilter.txt"
#define FILELOG_FILENAME L"filefilter.txt"
#define PKTLOG_NAME MAVEN_FOLDER_W PKTLOG_FILENAME
#define NETLOG_NAME MAVEN_FOLDER_W NETLOG_FILENAME
#define FILELOG_NAME MAVEN_FOLDER_W FILELOG_FILENAME

#define ADMIN_PORT_NAME L"\\MavenAdminPort"

#define SERVER_ID_STRING "Admin"
#define CONSOLE_ID_STRING "Console"
#define FILEFILTER_ID_STRING "FileFilter"
#define NETFILTER_ID_STRING "NetFilter"

#undef INCLUDE_TEST_CONSOLE /* define this to enable test console port */
#define HIDDEN_CONSOLE	/* define this if the console windows are hidden */

/* The SMSSInit subphase begins when the kernel passes control to the 
 * session manager process(Smss.exe).During this subphase, the system 
 * initializes the registry, loads and starts the devices and drivers 
 * that are not marked BOOT_START, and starts the subsystem processes.
 * SMSSInit ends when control is passed to Winlogon.exe.
 */
#define BOOT_SEQUENCE_END_NAME L"winlogon.exe" /* end function in boot sequence  */

#define LEARN_KEY L'*'
#define CONFIURATION_KEY '!'
#define WCONFIURATION_KEY L'!'

#define TRANSDUCER_FILEFILTER 0
#define TRANSDUCER_NETFILTER 1

 /* message IDs from server to mavenFileFilter app */
typedef enum _MAVEN_SERVER_NET_COMMAND {
	netCmdFilter,			/* set mavenNetFilter to filter mode */
	netCmdIdle,				/* set mavenNetFilter to idle mode */
	netCmdExit,				/* exit mavenNetFilter */
	netCmdStatus,			/* read status from driver and send to server */
	netCmdInvalid			/* unable to parse */
}MAVEN_SERVER_NET_COMMAND;
#define SERVER_NET_NUM_CMDS 4
#define SERVER_NET_CMD_FILTER NETFILTER_ID_STRING " Filter"
#define SERVER_NET_CMD_IDLE NETFILTER_ID_STRING " Idle"
#define SERVER_NET_CMD_EXIT NETFILTER_ID_STRING " Exit"
#define SERVER_NET_CMD_STATUS NETFILTER_ID_STRING " Status"
#define SERVER_CMD_NET_PREFIX NETFILTER_ID_STRING

 /* message IDs from server to mavenFileFilter app */
typedef enum _MAVEN_SERVER_COMMAND {
	cmdFilter,			/* set mavenFilter to filter mode */
	cmdLearn,			/* set mavenFilter to lern mode */
	cmdIdle,			/* set mavenFilter to idle mode */
	cmdReadWhitelist,	/* read whitelist from file and load in driver */
	cmdWriteWhitelist,	/* read whitelist from driver and save to file */
	cmdReset,			/* erase whitelist driver and set idle */
	cmdStatus,			/* read status from driver and send to server */
	cmdReadVersion,		/* read mavenFilter version */
	cmdReadLog,			/* read a log entry from driver */
	cmdExit,			/* exit mavenFilter */
	cmdInvalid			/* unable to parse */
}MAVEN_SERVER_COMMAND;
#define SERVER_NUM_CMDS 10
#define SERVER_CMD_FILTER FILEFILTER_ID_STRING " Filter"
#define SERVER_CMD_LEARN FILEFILTER_ID_STRING " Learn"
#define SERVER_CMD_IDLE FILEFILTER_ID_STRING " Idle"
#define SERVER_CMD_READWHITELIST FILEFILTER_ID_STRING " ReadWhitelist"
#define SERVER_CMD_WRITEWHITELIST FILEFILTER_ID_STRING " WriteWhitelist"
#define SERVER_CMD_RESET FILEFILTER_ID_STRING " Reset"
#define SERVER_CMD_STATUS FILEFILTER_ID_STRING " Status"
#define SERVER_CMD_READVERSION FILEFILTER_ID_STRING " ReadVersion"
#define SERVER_CMD_READLOG FILEFILTER_ID_STRING " ReadLog"
#define SERVER_CMD_EXIT FILEFILTER_ID_STRING " Exit"
#define SERVER_CMD_FILE_PREFIX FILEFILTER_ID_STRING

#define SERVER_CMD_SIZE PAYLOAD_MSG_SZ /* max size of server command */

#define SERVER_RESPONSE_SIZE PAYLOAD_MSG_SZ /* max size of server response */

typedef enum _MAVEN_RESPONSE {
	mavenError,		/* ERROR response to last command */
	mavenSuccess,	/* SUCCESS response to last command */
} MAVEN_RESPONSE;
#define MAVEN_RESPONSE_ERROR "FileFilter Error"
#define MAVEN_RESPONSE_SUCCESS "FileFilter Success"
#define MAVEN_RESPONSE_STATUS "FileFilter Status"

/* message IDs from the user app to driver */
typedef enum _MAVEN_COMMAND {
	mavenModeSetIdle,	/* set driver mode to idle */
	mavenModeSetLearn,	/* set driver mode to Learn */
	mavenModeSetFilter,	/* set driver mode to Filter */
	mavenModeSetReset,	/* set driver mode to Reset */
	mavenGetVersion,	/* Get driver version number */
	mavenReadConfig,	/* Read next configuration record, return Error if done */
	mavenWriteConfig,	/* Write configuration record to driver */
	mavenGetStatus,		/* Read current driver state */
	mavenGetLog			/* Get log entry */
} MAVEN_COMMAND;

typedef enum _OPERATING_MODE {
	MAVEN_BOOT,		/* boot sequence */
	MAVEN_IDLE,		/* wait for a processing command (default) */
	MAVEN_LEARN,	/* monitor file accesses and expand configuration accordingly */
	MAVEN_FILTER	/* use configuration to filter file access */
} OPERATING_MODE;

typedef enum _NETFILTER_STATE {
	NETFILTER_IDLE = 0,
	NETFILTER_FILTER = 1
}NETFILTER_STATE;

typedef enum _NETFILTER_LOG_MODE {
	NETFILTER_LOG_ALL,
	NETFILTER_LOG_NONE,
	NETFILTER_LOG_EVENTS
}NETFILTER_LOG_MODE;

#define MAVEN_SEVERITY_DEBUG 0
#define MAVEN_SEVERITY_INFO 1
#define MAVEN_SEVERITY_WARNING 2
#define MAVEN_SEVERITY_ERROR 3
#define MAVEN_SEVERITY_CRITICAL 4

#define EXTENSION_LENGHT (MAVEN_MAX_EXT_LENGTH + 1)
typedef struct _MAVEN_FILFILTER_RECORD {
	struct _MAVEN_FILFILTER_RECORD *next;	/* next entry */
	char	processImageName[MAX_PATH];		/* Image name including path */
	DWORD32	count;							/* number of times this process requested service */
	DWORD32	fail;							/* number of times this process request failed */
	char    extensions[MAVEN_MAX_EXT_ENTRIES][EXTENSION_LENGHT]; /* list of file types that this app may access */
} MAVEN_FILFILTER_RECORD;
#define MAVEN_FILFILTER_RECORD_SZ (sizeof(MAVEN_FILFILTER_RECORD) + 20) /* max record size as text */

#ifdef _WIN32
typedef struct __declspec(align(16)) _MAVEN_CMD_MESSAGE {
	MAVEN_COMMAND msgType;
	WCHAR payload[PAYLOAD_MSG_SZ];	/* message payload (optional) */
} MAVEN_CMD_MESSAGE;

typedef struct __declspec(align(16)) _MAVEN_RESPONSE_MESSAGE {
	MAVEN_RESPONSE msgType;
	WCHAR payload[PAYLOAD_MSG_SZ];	/* message payload (optional) */
} MAVEN_RESPONSE_MESSAGE;
#endif
