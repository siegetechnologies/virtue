/*++

Module Name: mavenFilefilter.cpp

Abstract:

This application runs in user space to provide monitoring and control of the 
mavenMiniFilter driver.



Environment:

User mode

Revision History:
Author Richard Carter - Siege Technologies, Manchester NH

V1.1	11/05/2017 - REC, written
V1.2	12/12/2017 - REC, Update for customer demo
V1.3	12/16/2017 - REC, Add username to log
V1.4	02/22/2018 - REC, Changed name to mavenFilefilter, use port for user interface
V1.5	03/16/2018 - REC, Bugfixes
V1.6	03/16/2018 - REC, Forward event log to fluentd
V1.7	03/27/2018 - REC, handle fragmented messages
V1.8	06/04/2018 - REC, remove csv file format support
V1.9	11/06/2018 - REC, learn command returns status
V1.10	01/18/2019 - REC, errors forwared as message to mavenClient

--*/
/* Copyright(c) 2019 Siege Technologies, 1105 Floyd Avenue Rome, NY 13440

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files(the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions :

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/
#include "stdafx.h"
static char module_name[] = { "mavenFilefilter mavenFilefilter.cpp" };

#undef MAVEN_DEBUG
#ifdef MAVEN_DEBUG
#ifdef HIDDEN_CONSOLE
FILE  *dbgLogFile = NULL;
#define PRINT_DBG(...) {fprintf(dbgLogFile, __VA_ARGS__); fflush(dbgLogFile);}
#define WPRINT_DBG(...) 
#else
#define PRINT_DBG(...) printf(__VA_ARGS__)
#define WPRINT_DBG(...) wprintf(__VA_ARGS__)
#endif
#else /* HIDDEN_CONSOLE */
#define PRINT_DBG(...)
#define WPRINT_DBG(...)
#endif

int charToWide(WCHAR* dest, const CHAR* source);

#define _BYTES_REMAINING (((size_t)serverResponsebuf) + sizeof(serverResponsebuf) - (size_t)pServerResponsebuf)
#define LINE_SIZE 132

static long lastErrorLine = 0;
static int numErrors = 0;
static HANDLE statusLogFile = INVALID_HANDLE_VALUE;
static HANDLE eventLogFile = INVALID_HANDLE_VALUE;
static HANDLE port = INVALID_HANDLE_VALUE;
static HANDLE hMessageProcess = INVALID_HANDLE_VALUE;
HANDLE hStopEvent;
static SOCKET ConnectSocket = INVALID_SOCKET;

#ifdef HIDDEN_CONSOLE
#define MAX_ERRORS 256
#define ERR_STR_LEN CONSOLE_LINE_SIZE

/***************************************************************************
* Name: reportError
*
* Routine Description: This function formats an error message and spawns
*	a thread to report the error.
*
* Returns: N/A
*
**************************************************************************/
void reportError(
	long errorLine,
	char *errorString,
	char *moduleName)
{
	char errorText[ERR_STR_LEN];
	/* prevent repetitive error reports */
	if ((lastErrorLine == errorLine) || (numErrors > MAX_ERRORS))
	{
		return;
	}
	else
	{
		int iResult;
		numErrors++;
		lastErrorLine = errorLine;
		snprintf(errorText, ERR_STR_LEN, "FileFilter error%s line %d %s", moduleName, errorLine, errorString);
		PRINT_DBG("****ERROR %s", errorText);
		if (ConnectSocket != INVALID_SOCKET)
		{
			PRINT_DBG("**** ERROR %s\n", errorText);
		}
		else
		{
			PRINT_DBG("**** ERROR socket error \n");
			return; /* don't log events if there's noplace to send them */
		}
		iResult = send(ConnectSocket, errorText,
			(int)strlen(errorText) + 1, 0);
		if (iResult == SOCKET_ERROR)
		{
			PRINT_DBG("send failed with error: %d\n", WSAGetLastError());
		}
	}
}

#define _ERROR(fmt,...) { char errorText[ERR_STR_LEN];  \
snprintf(errorText, ERR_STR_LEN, fmt, __VA_ARGS__); \
reportError(__LINE__, errorText, module_name); }
#else
#define _ERROR(fmt,...) fprintf(stderr, "%s line %d " fmt, __FILE__, __LINE__, __VA_ARGS__)
#endif


static const char mavenFilefilterVersion[] = "Maven File Filter V1.5\0";
static HANDLE mavenMinifilterPort = INVALID_HANDLE_VALUE;
static const char *serverString[SERVER_NUM_CMDS] = {
	SERVER_CMD_FILTER, SERVER_CMD_LEARN, SERVER_CMD_IDLE,
	SERVER_CMD_READWHITELIST, SERVER_CMD_WRITEWHITELIST, 
	SERVER_CMD_RESET, SERVER_CMD_STATUS, SERVER_CMD_READVERSION, 
	SERVER_CMD_READLOG, SERVER_CMD_EXIT
};
static char nullArg[] = "\0";

int wideToChar(CHAR* dest, const WCHAR* source);
int SIDtoUsername(PWCHAR outbuf, PWCHAR inbuf, DWORD *pBufLen);
int totalEventCount = 0;

#define VERSION_STRING " Maven File Filter V1.9"

/***************************************************************************
* Name: charToWide
*
* Routine Description: This function converts a character string to a
* wide string
*
* Returns:  number of characters in dest buffer (excluding terminator)
*
**************************************************************************/
int charToWide(WCHAR* dest, const CHAR* source)
{
	int i = 0;

	while (source[i] != '\0') {
		dest[i] = (WCHAR)source[i++];
	};
	dest[i] = 0; /* terminate */
	return i;
}

/***************************************************************************
* Name: recvMsg
*
* Routine Description: This function receives a message from a socket and
*	collects message fragments until the entire message is received.
*
* Returns: number of bytes received or zero if error
*
**************************************************************************/
int recvMsg(
	SOCKET s,	/* socket */
	char *buf,	/* pointer to receive buffer */
	int bufLen,	/* size of receive buffer */
	int *pWsaError
)
{
	int bytesReceived = 0;
	int index = 0;

	do {
		/* normally, the entire message is received at once, but
		* large messages can be fragmented */
		bytesReceived = recv(s, &buf[index], bufLen - index, 0);
		if (bytesReceived < 0)
		{
			*pWsaError = WSAGetLastError();
			if (*pWsaError == WSAETIMEDOUT)
			{
				return -1;	/* socket timed out */
			}
			_ERROR("recv error %d\n", *pWsaError);
			return 0;
		}
		index += bytesReceived;
		if ((bufLen - index) <= 0)
		{
			_ERROR("recv error - buffer overflow\n");
			return 0;
		}
	} while (buf[index - 1] != '\0');	/* defragment until string terminator found */
	return index;
}

/***************************************************************************
* Name: eventLogOpen
*
* Routine Description: This function opens the event log
*
* Returns: handle to file
*
**************************************************************************/
HANDLE eventLogOpen(void)
{
	HANDLE eventLogFile = INVALID_HANDLE_VALUE;

	/* open the log file */
	eventLogFile = CreateFile(FILELOG_NAME,
		GENERIC_WRITE | GENERIC_READ,
		FILE_SHARE_READ,
		NULL, // default security
		CREATE_ALWAYS,
		FILE_FLAG_SEQUENTIAL_SCAN | FILE_FLAG_NO_BUFFERING,
		NULL);

	if (eventLogFile == NULL)
	{
		_ERROR("unable to open file filter log file\n");
	}
	return eventLogFile;
}

/***************************************************************************
* Name: eventLogClose
*
* Routine Description: This function closes the event file
*
* Returns: N/A
*
**************************************************************************/
void eventLogClose(HANDLE eventLogFile)
{
	if (eventLogFile != INVALID_HANDLE_VALUE)
	{
		CloseHandle(eventLogFile);
	}
}

/***************************************************************************
* Name: logEvent
*
* Routine Description: This function logs an entry to the event log
*
* Returns: N/A
*
**************************************************************************/
void logEvent(
	double timePassed,
	char *outBuf,
	HANDLE eventLogFile
)
{
	BOOL errorFlag = FALSE;
	DWORD dwBytesToWrite;
	DWORD dwBytesWritten = 0;

	dwBytesToWrite = (DWORD)strlen(outBuf);
	errorFlag = WriteFile(
		eventLogFile,       // open file handle
		outBuf,				// start of data to write
		dwBytesToWrite,		// number of bytes to write
		&dwBytesWritten,	// number of bytes that were written
		NULL);				// no overlapped structure

	if (errorFlag == FALSE)
	{
		_ERROR("logEvent Unable to write to event log file.\n");
	}
	else if (dwBytesWritten != dwBytesToWrite)
	{
		// This is an error because a synchronous write that results in
		// success (WriteFile returns TRUE) should write all data as
		// requested. This would not necessarily be the case for
		// asynchronous writes.
		_ERROR("logEvent error writing to event log file.\n");
	}

}

/***************************************************************************
* Name: statusLogOpen
*
* Routine Description: This function opens the status log file
*
* Returns: handle to file
*
**************************************************************************/
HANDLE statusLogOpen(void)
{
	HANDLE statusLogFile = INVALID_HANDLE_VALUE;

	/* open the log file */
	statusLogFile = CreateFile(FILELOG_NAME,
		GENERIC_WRITE | GENERIC_READ,
		FILE_SHARE_READ,
		NULL, // default security
		CREATE_ALWAYS,
		FILE_FLAG_SEQUENTIAL_SCAN | FILE_FLAG_WRITE_THROUGH,
		NULL);

	if (statusLogFile == NULL)
	{
		_ERROR("unable to open file %ls\n", FILELOG_NAME);
	}
	return statusLogFile;
}

/***************************************************************************
* Name: parseStatus
*
* Routine Description: This function searches the filefilter status string
* for a the heartbeat and event count.
*
* Mode = Learn, Heartbeat = 3, Log Size = 0; <optional comment here>
*
* Returns:  N/A
*
*/
void parseStatus(char *outBuf, int *pEventCount, int *pHeartbeat, char *pDefaultMode)
{
	int keyFound = 0;
	*pEventCount = 0;
	*pHeartbeat = 0;
	BOOL modeFound = FALSE;

	while ((*outBuf != '\n') && (*outBuf != '\0'))
	{
		/* look for =sign */
		if (*outBuf == '=')
		{
			keyFound++;	/* Mode */
		}
		if ((keyFound == 1) && !modeFound)
		{
			if (isalpha(*outBuf))
			{
				modeFound = TRUE;
				/* Look for valid mode and set accordingly */
				if ((*outBuf == 'i') || (*outBuf == 'I'))
				{
					*pDefaultMode = 'I';
				}
				if ((*outBuf == 'f') || (*outBuf == 'F'))
				{
					*pDefaultMode = 'F';
				}
				if ((*outBuf == 'l') || (*outBuf == 'L'))
				{
					*pDefaultMode = 'L';
				}
				if ((*outBuf == 'b') || (*outBuf == 'B'))
				{
					*pDefaultMode = 'B';
				}
			}
		}
			/* if we found the second =sign */
		if (keyFound == 2)
		{
			/* convert count from ascii to decimal */
			if ((*outBuf >= '0') && (*outBuf <= '9'))
			{
				*pHeartbeat *= 10;
				*pHeartbeat += *outBuf - '0';
			}
		}
		if (keyFound == 3)
		{
			/* convert count from ascii to decimal */
			if ((*outBuf >= '0') && (*outBuf <= '9'))
			{
				*pEventCount *= 10;
				*pEventCount += *outBuf - '0';
			}
			if (*outBuf == ';')
			{
				break; /* done */
			}
		}

		outBuf++; /* next char */
	}
}

/***************************************************************************
* Name: statusLogClose
*
* Routine Description: This function closes the status log file
*
* Returns: N/A
*
**************************************************************************/
void statusLogClose(HANDLE statusLogFile)
{
	if (statusLogFile != INVALID_HANDLE_VALUE)
	{
		CloseHandle(statusLogFile);
	}
}

/***************************************************************************
* Name: logStatus
*
* Routine Description: This function logs status to the filefiler log
*	file. It also reads any events reported and logs and sends messages for
*	each.
*
* Returns: N/A
*
**************************************************************************/
void logStatus(
	int eventCount,
	HANDLE statusLogFile,
	char *pServerResponsebuf
)
{
	CHAR eventMessage[PAYLOAD_MSG_SZ], *pEventMessage;
	MAVEN_RESPONSE_MESSAGE responseMessage;
	MAVEN_CMD_MESSAGE commandMessage;
	DWORD bytesReturned = sizeof(MAVEN_RESPONSE_MESSAGE);
	HRESULT hResult = S_OK;
	BOOL errorFlag = FALSE;
	DWORD dwBytesToWrite;
	DWORD dwBytesWritten = 0;
	int i, j;
	WCHAR userName[MAX_USERNAME_LEN];
	DWORD bufLen;

	PRINT_DBG("mavenFileFilter - logs status %s\n", pServerResponsebuf);

	dwBytesToWrite = (DWORD)strlen(pServerResponsebuf);
	pServerResponsebuf[dwBytesToWrite++] = '\n'; /* add newline to string */
	pServerResponsebuf[dwBytesToWrite] = '\0';
	errorFlag = WriteFile(
		statusLogFile,      // open file handle
		pServerResponsebuf,	// start of data to write
		dwBytesToWrite,		// number of bytes to write
		&dwBytesWritten,	// number of bytes that were written
		NULL);				// no overlapped structure

	if (errorFlag == FALSE)
	{
		_ERROR("logStatus Unable to write to %ls.\n", FILELOG_NAME);
	}
	else if (dwBytesWritten != dwBytesToWrite)
	{
		// This is an error because a synchronous write that results in
		// success (WriteFile returns TRUE) should write all data as
		// requested. This would not necessarily be the case for
		// asynchronous writes.
		_ERROR("logStatus error writing to %ls\n", FILELOG_NAME);
	}

	PRINT_DBG("mavenFileFilter - finds %d events \n", eventCount);

	if (ConnectSocket == INVALID_SOCKET)
	{
		return; /* don't grab events if there's noplace to send them */
	}

	/* for each event reported */
	for (j = 0; j < eventCount; j++)
	{
		commandMessage.msgType = mavenGetLog;

		/* query the driver for the event message */
		hResult = FilterSendMessage(mavenMinifilterPort,
			&commandMessage,
			sizeof(MAVEN_CMD_MESSAGE),
			&responseMessage,
			sizeof(MAVEN_RESPONSE_MESSAGE),
			&bytesReturned);

		if (responseMessage.msgType != mavenSuccess) {
			return;
		}

		/* id the destination socket */
		pEventMessage = eventMessage;
		pEventMessage += sprintf_s(pEventMessage, sizeof(eventMessage), 
			FILEFILTER_ID_STRING " event,");
		
		/* insert user name in response buffer */

		bufLen = MAX_USERNAME_LEN;	/* max length of username buffer */
		i = SIDtoUsername(userName, responseMessage.payload, &bufLen);
		if (i != 0) {
			(void)wideToChar(pEventMessage, userName);
			pEventMessage += bufLen;
		}
		/* put in a comma delimeter */
		*pEventMessage++ = ',';

		/* print rest of payload */
		(void)wideToChar(pEventMessage, &responseMessage.payload[i]);

		PRINT_DBG("mavenFileFilter - reports event %s \n", eventMessage);
		/* send to fluentd */
		if (send(ConnectSocket, eventMessage, (int)strlen(eventMessage) + 1, 0) == SOCKET_ERROR) 
		{
			hResult = NS_E_INTERNAL_SERVER_ERROR;
			_ERROR("send failed with error: %d\n", WSAGetLastError());
		}
		dwBytesToWrite = (DWORD)strlen(eventMessage);
		errorFlag = WriteFile(
			statusLogFile,      // open file handle
			eventMessage,		// start of data to write
			dwBytesToWrite,		// number of bytes to write
			&dwBytesWritten,	// number of bytes that were written
			NULL);				// no overlapped structure

		if (errorFlag == FALSE)
		{
			_ERROR("logStatus Unable to write to %ls.\n", FILELOG_NAME);
		}
		else if (dwBytesWritten != dwBytesToWrite)
		{
			// This is an error because a synchronous write that results in
			// success (WriteFile returns TRUE) should write all data as
			// requested. This would not necessarily be the case for
			// asynchronous writes.
			_ERROR("logStatus error writing to %ls\n", FILELOG_NAME);
		}
	} /* for each event reported */
}

/***************************************************************************
* Name: wideToChar
*
* Routine Description: This function converts a wide character string to a
*	character string.
*
* Returns: number of characters in dest buffer excluding null terminator
*
**************************************************************************/
int wideToChar(CHAR* dest, const WCHAR* source)
{
	int i = 0;

	do {
		dest[i] = (CHAR)source[i];
	} while (source[++i] != '\0');
	dest[i] = 0; /* null terminate */
	return i;
}

/***************************************************************************
* Name: SIDtoUsername
*
* Routine Description: This function extracts the SID from the beginning
*	of the passed payload and uses it to obtain the user name of the
*	associated process.  It then copies the user name to the output buffer.
*
* Returns:  Number of characters advanced in the passsed string.  Zero if error
*
**************************************************************************/
int SIDtoUsername(
	PWCHAR outbuf,  /* user name */
	PWCHAR inbuf,	/* SID character string */
	DWORD *pBufLen	/* length of name (chars) */
)
{
	BOOL status;
	int i = 0;
	WCHAR stringSecurityDescriptor[PAYLOAD_MSG_SZ];
	WCHAR referencedDomainName[MAX_USERNAME_LEN];
	PSECURITY_DESCRIPTOR pSID;
	DWORD domainnameLen = MAX_USERNAME_LEN;
	SID_NAME_USE eUse = SidTypeUnknown;

	/* copy first part of string, SID, to a new buffer (so we can terminate it) */
	while (TRUE) {
		if (inbuf[i] == '\t') {
			break;
		}
		if (i == (PAYLOAD_MSG_SZ - 1)) {
			return 0;	/* buffer overflow */
		}
		stringSecurityDescriptor[i] = inbuf[i]; /* copy to temporary buffer for later processing */
		i++;
	}
	stringSecurityDescriptor[i] = 0; /* terminate */

	if (ConvertStringSidToSid(stringSecurityDescriptor, &pSID) == 0)
	{
		return 0;	/* unable to convert */
	}

	if (!IsValidSid(pSID)) {
		return 0;	/* unable to convert */
	}


	status = LookupAccountSid(
		NULL,
		pSID,
		outbuf,
		pBufLen,
		referencedDomainName,
		&domainnameLen,
		&eUse);

	if (status == 0)
	{
		PRINT_DBG("LookupAccountSid failed (0x%x\n)", GetLastError());
		return 0;
	}
	/* put a space after the user name */
	outbuf[*pBufLen++] = ' ';

	return i; /* number of characters advanced in input buffer */

}

/***************************************************************************
* Name: parseServerCommand
*
* Routine Description: This function matches the passed string for a match
*	with a predefined set of server commands.
*
* Returns: An enumerated number for the server command and a pointer to
*	the argument list (if present)
*
**************************************************************************/
MAVEN_SERVER_COMMAND parseServerCommand(
	char *serverRecvbuf,
	char **argString)
{
	int i;
	size_t cmdLen;
	*argString = nullArg;
	PRINT_DBG("mavenFileFilter - parsing %s\n", serverRecvbuf);
	for (i = 0; i < SERVER_NUM_CMDS; i++)
	{
		cmdLen = strlen(serverString[i]);
		if (strncmp(serverString[i], serverRecvbuf, cmdLen) == 0) {
			/* argument uses space as field seperator */
			if (serverRecvbuf[cmdLen] == ' ') {
				*argString = serverRecvbuf + cmdLen + 1;
			}
			break; /* found valid command */
		}
	}
	return (MAVEN_SERVER_COMMAND)i;
}

/***************************************************************************
* Name: getStatus
*
* Routine Description: This function queries the minifilter for status and
*	formats a status response message.  It also logs that status.
*
* Returns: N/A
*
**************************************************************************/
void getStatus(
	HANDLE statusLogFile,
	MAVEN_CMD_MESSAGE *pCommandMessage,
	MAVEN_RESPONSE_MESSAGE *pResponseMessage,
	double timePassed,
	char *serverResponsebuf
)
{
	char *pServerResponsebuf = serverResponsebuf;
	DWORD bytesReturned = sizeof(MAVEN_RESPONSE_MESSAGE);
	HRESULT hResult = S_OK;
	pCommandMessage->msgType = mavenGetStatus;
	int heartbeat = HEARTBEAT_DELAY / 1000;
	char defaultMode = 'I';
	int eventCount;
	int socketTimeout = HEARTBEAT_DELAY;


	hResult = FilterSendMessage(mavenMinifilterPort,
		pCommandMessage,
		sizeof(MAVEN_CMD_MESSAGE),
		pResponseMessage,
		sizeof(MAVEN_RESPONSE_MESSAGE),
		&bytesReturned);

	if (pResponseMessage->msgType != mavenSuccess) {
		pServerResponsebuf += sprintf_s(pServerResponsebuf,
			_BYTES_REMAINING,
			"Unable to get driver status");
		_ERROR("Unable read current driver state\n");
		return;
	}
	pServerResponsebuf += sprintf_s(serverResponsebuf, SERVER_CMD_SIZE,
		"%s ", MAVEN_RESPONSE_STATUS);
	pServerResponsebuf += wideToChar(pServerResponsebuf, pResponseMessage->payload);
	pServerResponsebuf -= 1; /* write over \n */
	pServerResponsebuf += sprintf_s(pServerResponsebuf, SERVER_CMD_SIZE - strlen(serverResponsebuf),
		" Time=%8.2f ", timePassed);

	/* check the status message for reported events.  If found, query the filter
	* and report events.
	*/
	parseStatus(serverResponsebuf, &eventCount, &heartbeat, &defaultMode);
	if (heartbeat != (socketTimeout / 1000))
	{
		socketTimeout = heartbeat * 1000;
		if (setsockopt(ConnectSocket,
			SOL_SOCKET,
			SO_RCVTIMEO,
			(const char *)&socketTimeout,
			sizeof(socketTimeout)) != 0)
		{
			hResult = NS_E_INTERNAL_SERVER_ERROR;
			_ERROR("mavenFileFilter - unable to set socket timeout\n");
			goto GetStatus_Exit;
		}

	}

	/* log status to file and report each event */
	logStatus(eventCount, statusLogFile, serverResponsebuf);

	pServerResponsebuf -= 1; /* overwrite newline */

	totalEventCount += eventCount;
	sprintf_s(pServerResponsebuf, SERVER_CMD_SIZE - strlen(serverResponsebuf), " totalEvents = %d\n",
		totalEventCount);

	WPRINT_DBG(L"Maven state - %ls\n", pResponseMessage->payload);
	return;

	GetStatus_Exit:
	/* format default error response message */
	sprintf_s(serverResponsebuf,
		_BYTES_REMAINING, "%s\t",
		MAVEN_RESPONSE_ERROR);
}


/***************************************************************************
* Name: messageProcessThread
*
* Routine Description: This thread receives and processes messages from
*	the filefilter driver.
*
* Returns: 0
*
**************************************************************************/
DWORD WINAPI messageProcessThread(LPVOID thread_data)
{
	HRESULT hResult = S_OK;
	int iResult;
	char *pServerResponsebuf;
	char serverRecvbuf[SERVER_CMD_SIZE];
	char serverResponsebuf[SERVER_RESPONSE_SIZE];
	MAVEN_SERVER_COMMAND serverCommand;
	int index, chars, i;
	DWORD bufLen;
	char defaultMode = 'L';
	char *argString;
	MAVEN_CMD_MESSAGE commandMessage;
	MAVEN_RESPONSE_MESSAGE responseMessage;
	DWORD bytesReturned = sizeof(MAVEN_RESPONSE_MESSAGE);
	FILE *fptr;
	CHAR payloadChar[PAYLOAD_MSG_SZ];
	WCHAR userName[MAX_USERNAME_LEN];
	int heartbeat = HEARTBEAT_DELAY / 1000;

	LARGE_INTEGER base;
	LARGE_INTEGER timestamp;
	LARGE_INTEGER freq;
	double timePassed;

	// Set up timing:
	QueryPerformanceFrequency(&freq);
	QueryPerformanceCounter(&base);

	while (SUCCEEDED(hResult))
	{
		int wsaError = 0;
		pServerResponsebuf = (char *)((size_t)serverResponsebuf); /* start forming output string */

		PRINT_DBG("mavenFileFilter - receive\n");
		iResult = recvMsg(ConnectSocket, serverRecvbuf, SERVER_CMD_SIZE, &wsaError);
		/* compute elapsed time from start(seconds) */
		QueryPerformanceCounter(&timestamp);
		timePassed = (double)(timestamp.QuadPart - base.QuadPart) /
			(double)freq.QuadPart;

		argString = NULL;
		if ((wsaError == 0) && (iResult > 0))
		{
			/* we received a message from the server */
			serverCommand = parseServerCommand(serverRecvbuf, &argString);
			PRINT_DBG("mavenFileFilter - Bytes received: %d, cmd=%d\n", iResult, serverCommand);
		}
		/* if we have a socket timeout */
		else if ((wsaError == WSAETIMEDOUT) || (wsaError < WSABASEERR))
		{
			/* send heartbeat */
			serverCommand = cmdStatus;
		}
		else
		{
			_ERROR("receive failed with error: %d\n", wsaError);
			//hResult = E_HANDLE;
			//goto Main_Exit;
			continue;
		}

		/* format default error response message */
		pServerResponsebuf += sprintf_s(pServerResponsebuf,
			_BYTES_REMAINING, "%s\t",
			MAVEN_RESPONSE_ERROR);

		PRINT_DBG("mavenFileFilter - dispatch command %d\n", serverCommand);
		/* dispatch command */
		switch (serverCommand)
		{
		case cmdLearn: /* set Learn mode */
			commandMessage.msgType = mavenModeSetLearn;
			PRINT_DBG("mavenFileFilter - cmdLearn\n");

			hResult = FilterSendMessage(mavenMinifilterPort,
				&commandMessage,
				sizeof(MAVEN_CMD_MESSAGE),
				&responseMessage,
				sizeof(MAVEN_RESPONSE_MESSAGE),
				&bytesReturned);

			if (responseMessage.msgType != mavenSuccess) {
				pServerResponsebuf += sprintf_s(pServerResponsebuf,
					_BYTES_REMAINING,
					"Unable to set Learn mode");
				PRINT_DBG("mavenFileFilter - **** ERROR: Unable to set Learn mode\n");
				goto Send_Cmd_Response;
			}

			/* format status message as response */
			getStatus(
				statusLogFile,
				&commandMessage,
				&responseMessage,
				timePassed,
				serverResponsebuf);

			/* send command response to server */
			goto Send_Cmd_Response;

		case cmdIdle: /* set idle mode */
			commandMessage.msgType = mavenModeSetIdle;
			PRINT_DBG("mavenFileFilter - cmdIdle\n");

			hResult = FilterSendMessage(mavenMinifilterPort,
				&commandMessage,
				sizeof(MAVEN_CMD_MESSAGE),
				&responseMessage,
				sizeof(MAVEN_RESPONSE_MESSAGE),
				&bytesReturned);

			if (responseMessage.msgType != mavenSuccess) {
				pServerResponsebuf += sprintf_s(pServerResponsebuf,
					_BYTES_REMAINING,
					"Unable to set Idle mode");
				PRINT_DBG("mavenFileFilter - **** ERROR: Unable to set Idle mode\n");
				goto Send_Cmd_Response;
			}

			/* format status message as response */
			getStatus(
				statusLogFile,
				&commandMessage,
				&responseMessage,
				timePassed,
				serverResponsebuf);

			/* send command response to server */
			goto Send_Cmd_Response;

		case cmdReadWhitelist: /* read whitelist from driver and write to file */
			PRINT_DBG("mavenFileFilter - cmdReadWhitelist %s \n", argString);
			/* this command requires an argument */

			if ((argString == NULL) || (strlen(argString) < 2))
			{
				/* send error command response to server */
				goto Send_Cmd_Response;
			}
			/* file name is argument */
			if ((fopen_s(&fptr, argString, "w") != 0) || (fptr == NULL)) {
				pServerResponsebuf += sprintf_s(pServerResponsebuf,
					_BYTES_REMAINING,
					"Unable to open file");
				PRINT_DBG("mavenFileFilter - **** ERROR: Unable to open file\n");
				goto Send_Cmd_Response;
			}

			/* first write configuration to file */
			/* !mode = <mode>, heartbeat = <heartbeat>; <comment> */
			fprintf(fptr, "!mode = %c, heartbeat = %d "
				"; mode = [Learn, Idle, Filter], heartbeat = <seconds> \n", defaultMode, heartbeat);

			/* read each record from driver and write to file */
			for (index = 0; index < MAVEN_NUM_PROC; index++) {
				commandMessage.msgType = mavenReadConfig;
				chars = swprintf(commandMessage.payload, PAYLOAD_MSG_SZ, L"%ld", index);

				hResult = FilterSendMessage(mavenMinifilterPort,
					&commandMessage,
					sizeof(MAVEN_CMD_MESSAGE),
					&responseMessage,
					sizeof(MAVEN_RESPONSE_MESSAGE),
					&bytesReturned);

				if (responseMessage.msgType != mavenSuccess) {
					/* end of file */
					break;
				}

				if (bytesReturned == 0) {
					break;
				}
				else {
					pServerResponsebuf = serverResponsebuf; /* start forming output string */
					/* format success response message(overwriting default error) */
					pServerResponsebuf += sprintf_s(serverResponsebuf, sizeof(serverResponsebuf),
						"%s\t", MAVEN_RESPONSE_SUCCESS);
					WPRINT_DBG(L"%s\n", responseMessage.payload);
					/* convert from wide to byte string */
					(void)wideToChar(payloadChar, responseMessage.payload);
					fprintf(fptr, "%s\n", payloadChar);
				}
			}
			fclose(fptr);
			goto Send_Cmd_Response;


		case cmdWriteWhitelist: /* read whitelist from file and send to driver */
			PRINT_DBG("mavenFileFilter - cmdWriteWhitelist %s \n", argString);
			/* this command requires an argument */
			if (strlen(argString) < 2)
			{
				/* send error command response to server */
				goto Send_Cmd_Response;
			}
			/* file name is argument */
			if ((fopen_s(&fptr, argString, "r") != 0) || (fptr == NULL)) {
				pServerResponsebuf += sprintf_s(pServerResponsebuf,
					_BYTES_REMAINING,
					"Unable to open file ");
				PRINT_DBG("mavenFileFilter - **** ERROR: Unable to open file\n");
				goto Send_Cmd_Response;
			}
			index = 0;
			while (fgets(payloadChar, PAYLOAD_MSG_SZ, fptr))
			{
				PRINT_DBG("mavenFileFilter - read %s\n", payloadChar);
				/* if file contains configuration information in first line */
				if (payloadChar[0] == CONFIURATION_KEY)
				{
					/* ignore, driver can't use it */
					continue;
				}
				/* prepend line number and then send to driver */
				swprintf_s(commandMessage.payload, PAYLOAD_MSG_SZ, L"%06d\t", index++);
				(void)charToWide(&commandMessage.payload[7], payloadChar);
				commandMessage.msgType = mavenWriteConfig;
				WPRINT_DBG(L"sending\n%s\n", commandMessage.payload);
				hResult = FilterSendMessage(mavenMinifilterPort,
					&commandMessage,
					sizeof(MAVEN_CMD_MESSAGE),
					&responseMessage,
					sizeof(MAVEN_RESPONSE_MESSAGE),
					&bytesReturned);

				if (responseMessage.msgType != mavenSuccess) {
					pServerResponsebuf += sprintf_s(pServerResponsebuf,
						_BYTES_REMAINING,
						"Unable to write configuration  whitelist[%d]", index);
					_ERROR("Unable to write configuration \n");
					WPRINT_DBG(L"-- %s\n", responseMessage.payload);
					fclose(fptr);
					goto Send_Cmd_Response;
				}
			}

			/* end of file, format success response message (overwriting default error) */
			fclose(fptr);

			/* fall through to set filter mode */

		case cmdFilter:
			commandMessage.msgType = mavenModeSetFilter;
			PRINT_DBG("mavenFileFilter - cmdFilter\n");

			hResult = FilterSendMessage(mavenMinifilterPort,
				&commandMessage,
				sizeof(MAVEN_CMD_MESSAGE),
				&responseMessage,
				sizeof(MAVEN_RESPONSE_MESSAGE),
				&bytesReturned);

			if (responseMessage.msgType != mavenSuccess) {
				pServerResponsebuf += sprintf_s(pServerResponsebuf,
					_BYTES_REMAINING,
					"Unable to set Filter mode");
				PRINT_DBG("mavenFileFilter - **** ERROR: Unable to set Filter mode\n");
				goto Send_Cmd_Response;
			}

			/* format status message as response */
			getStatus(
				statusLogFile,
				&commandMessage,
				&responseMessage,
				timePassed,
				serverResponsebuf);

			goto Send_Cmd_Response;

		case cmdReset: /* set reset mode */
			PRINT_DBG("mavenFileFilter - cmdReset\n");
			commandMessage.msgType = mavenModeSetReset;

			hResult = FilterSendMessage(mavenMinifilterPort,
				&commandMessage,
				sizeof(MAVEN_CMD_MESSAGE),
				&responseMessage,
				sizeof(MAVEN_RESPONSE_MESSAGE),
				&bytesReturned);

			if (responseMessage.msgType != mavenSuccess) {
				pServerResponsebuf += sprintf_s(pServerResponsebuf,
					_BYTES_REMAINING,
					"Unable to reset filter");
				_ERROR("Unable to reset filter\n");
				goto Send_Cmd_Response;
			}
			pServerResponsebuf = serverResponsebuf; /* start forming output string */

			/* format success response message (overwriting default error) */
			sprintf_s(serverResponsebuf, sizeof(serverResponsebuf),
				"%s\t", MAVEN_RESPONSE_SUCCESS);
			goto Send_Cmd_Response;

		case cmdStatus: /* get Current Operating Mode */
			PRINT_DBG("mavenFileFilter - cmdStatus\n");

			/* format status message as response */
			getStatus(
				statusLogFile,
				&commandMessage,
				&responseMessage,
				timePassed,
				serverResponsebuf);

			WPRINT_DBG(L"Maven state - %ls\n", responseMessage.payload);
			goto Send_Cmd_Response;

		case cmdReadLog: /* get log entry */
			commandMessage.msgType = mavenGetLog;
			PRINT_DBG("mavenFileFilter - cmdReadLog\n");

			pServerResponsebuf = serverResponsebuf; /* start forming output string */
			pServerResponsebuf += sprintf_s(pServerResponsebuf,
				_BYTES_REMAINING, "%s\t",
				MAVEN_RESPONSE_SUCCESS);

			hResult = FilterSendMessage(mavenMinifilterPort,
				&commandMessage,
				sizeof(MAVEN_CMD_MESSAGE),
				&responseMessage,
				sizeof(MAVEN_RESPONSE_MESSAGE),
				&bytesReturned);

			if (responseMessage.msgType != mavenSuccess) {
				pServerResponsebuf += sprintf_s(pServerResponsebuf,
					_BYTES_REMAINING,
					"Driver log is empty");
				PRINT_DBG("mavenFileFilter - end of driver log\n");
				goto Send_Cmd_Response;
			}
			/* insert user name in response buffer */
			bufLen = MAX_USERNAME_LEN;	/* max length of username buffer */
			i = SIDtoUsername(userName, responseMessage.payload, &bufLen);
			if (i != 0) {
				(void)wideToChar(pServerResponsebuf, userName);
				pServerResponsebuf += bufLen;
			}
			/* print rest of payload */
			i = wideToChar(pServerResponsebuf, &responseMessage.payload[i]);

			/* make sure that we have newline at end */
			if ((i != 0) && (pServerResponsebuf[i - 1] != '\n'))
			{
				pServerResponsebuf[i] = '\n';
				pServerResponsebuf[i + 1] = '\0';
			}

			logEvent(timePassed, pServerResponsebuf, eventLogFile);

			/* format command response to server */
			goto Send_Cmd_Response;

		case cmdReadVersion: /* get version */
			commandMessage.msgType = mavenGetVersion;
			PRINT_DBG("mavenFileFilter - cmdReadVersion\n");

			hResult = FilterSendMessage(mavenMinifilterPort,
				&commandMessage,
				sizeof(MAVEN_CMD_MESSAGE),
				&responseMessage,
				sizeof(MAVEN_RESPONSE_MESSAGE),
				&bytesReturned);

			if (responseMessage.msgType != mavenSuccess)
			{
				pServerResponsebuf += sprintf_s(pServerResponsebuf,
					_BYTES_REMAINING,
					"Unable to read driver version");
				PRINT_DBG("mavenFileFilter - **** ERROR: Unable to read driver version\n");
				goto Send_Cmd_Response;
			}
			pServerResponsebuf = serverResponsebuf; /* start forming output string */
			/* format success response message (overwriting default error) */
			pServerResponsebuf += sprintf_s(serverResponsebuf, sizeof(serverResponsebuf),
				"%s  %s  ", MAVEN_RESPONSE_SUCCESS, mavenFilefilterVersion);
			(void)wideToChar(pServerResponsebuf, responseMessage.payload);
			goto Send_Cmd_Response;

		case cmdExit: /* exit */
			PRINT_DBG("mavenFileFilter - cmdExit\n");
			pServerResponsebuf = serverResponsebuf; /* start forming output string */
			pServerResponsebuf += sprintf_s(pServerResponsebuf,
				_BYTES_REMAINING, "%s\t",
				MAVEN_RESPONSE_SUCCESS "mavenFileFilter Exits\n");
			hResult = E_ABORT;
			break;
			/* fall through */

		case cmdInvalid:
		default:
			PRINT_DBG("mavenFileFilter - invalid command\n");
			/* force a terminator in case the buffer has junk */
			serverRecvbuf[20] = '\0';
			pServerResponsebuf = serverResponsebuf; /* start forming output string */
			pServerResponsebuf += sprintf_s(serverResponsebuf,
				_BYTES_REMAINING, "INVALID COMMAND %s\t", serverRecvbuf);

		Send_Cmd_Response:
			/* Send a response message */
			PRINT_DBG("mavenFileFilter - send server response %s\n", serverResponsebuf);
			iResult = send(ConnectSocket, serverResponsebuf,
				(int)strlen(serverResponsebuf) + 1, 0);
			if (iResult == SOCKET_ERROR)
			{
				_ERROR("send failed with error: %d\n", WSAGetLastError());
				break;
			}

			PRINT_DBG("mavenFileFilter - (%x) Bytes Sent: %ld\n", bytesReturned, iResult);

			break;
		} /* end switch */
	} /* end while */
	PRINT_DBG("mavenFileFilter - exits hresult = %d\n", hResult);
	SetEvent(hStopEvent); /* error, terminate all apps */
	return 0;
}

/***************************************************************************
* Name: StopService
*
* Routine Description: This function is the service exit routine.  It cleans 
*	up resources used .
*
* Returns: 0
*
**************************************************************************/
void StopService(void)
{
	HRESULT hResult = S_OK;
	int iResult;
	PRINT_DBG("StopService\n");
	if (ConnectSocket != INVALID_SOCKET)
	{
		/*  shutdown the connection */
		iResult = shutdown(ConnectSocket, SD_BOTH);
		if (iResult == SOCKET_ERROR)
		{
			_ERROR("shutdown failed with error: %d\n", WSAGetLastError());
			closesocket(ConnectSocket);
			WSACleanup();
			hResult = E_UNEXPECTED;
		}
	}

	statusLogClose(statusLogFile);
	eventLogClose(eventLogFile);

	if (mavenMinifilterPort != INVALID_HANDLE_VALUE) {
		CloseHandle(mavenMinifilterPort);
	}
	if (statusLogFile != INVALID_HANDLE_VALUE) {
		CloseHandle(statusLogFile);
	}
	if (eventLogFile != INVALID_HANDLE_VALUE) {
		CloseHandle(eventLogFile);
	}
	if (port != INVALID_HANDLE_VALUE) {
		CloseHandle(port);
	}
	if (hMessageProcess != INVALID_HANDLE_VALUE) {
		CloseHandle(hMessageProcess);
	}

	PRINT_DBG("mavenFileFilter - mavenFilefilter exits\n");
#ifdef MAVEN_DEBUG
	if (dbgLogFile != NULL)
	{
		fclose(dbgLogFile);
		dbgLogFile = NULL;
	}
#endif

}

/***************************************************************************
* Name: mavenFilefilter
*
* Routine Description: This is the entry function for the mavenFilefilter service. 
*
* Returns: 0
*
**************************************************************************/
int mavenFilefilter(void)
{
	HRESULT hResult = S_OK;


	WSADATA wsaData;
	int socketTimeout = HEARTBEAT_DELAY;
	struct addrinfo *result = NULL;
	struct addrinfo *ptr = NULL;
	struct addrinfo hints;
	int iResult;


#if 0 // to attach debugger early
	printf("mavenFilefilter pauses >");
	printf("%c", getchar()); /* for debug */
#endif
	hStopEvent = CreateEvent(NULL, TRUE, FALSE, NULL);

#if (defined HIDDEN_CONSOLE) &&(defined MAVEN_DEBUG)
	fopen_s(&dbgLogFile, "C:\\maven\\mavenFilefilterLog.txt", "w");
#endif

#ifdef HIDDEN_CONSOLE
	FreeConsole(); /* closes the console and makes the window hidden */
#endif

	PRINT_DBG("mavenFileFilter - Open the port\n");

	/* Open the port that is used to talk to filter driver */
	hResult = FilterConnectCommunicationPort(MAVEN_PORT_NAME,
		0,
		NULL,
		0,
		NULL,
		&mavenMinifilterPort);

	if (IS_ERROR(hResult)) {

		_ERROR("Could not connect to filter: 0x%08x\n", hResult);
		goto Main_Exit;
	}

	PRINT_DBG("mavenFileFilter - Initialize Winsock\n");
	/*  Initialize Winsock */
	iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (iResult != 0) {
		_ERROR("WSAStartup failed with error: %d\n", iResult);
		goto Main_Exit;
	}
	memset(&hints, 0, sizeof(hints));
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_protocol = IPPROTO_TCP;

	/* Resolve the server address and port */
	iResult = getaddrinfo(NULL, FILEFILTER_PORT_NUMBER, &hints, &result);
	if (iResult != 0) {
		_ERROR("getaddrinfo failed with error: %d\n", iResult);
		WSACleanup();
		return 1;
	}
	PRINT_DBG("mavenFileFilter - Attempt to connect to an address \n");
	/* Attempt to connect to an address until one succeeds */
	while (ConnectSocket == INVALID_SOCKET) {
		PRINT_DBG("mavenFileFilter - Attempt to connect to an address \n");
		for (ptr = result; ptr != NULL; ptr = ptr->ai_next) {

			PRINT_DBG(".");
			/* Create a SOCKET for connecting to server */
			ConnectSocket = socket(ptr->ai_family, ptr->ai_socktype,
				ptr->ai_protocol);
			if (ConnectSocket == INVALID_SOCKET) {
				WSACleanup();
				hResult = NS_E_SERVER_UNAVAILABLE;
				PRINT_DBG("mavenFileFilter - failed to connect to server \n");
				goto Main_Exit;
			}

			/* Connect to server. */
			iResult = connect(ConnectSocket, ptr->ai_addr, (int)ptr->ai_addrlen);
			if (iResult == SOCKET_ERROR) {
				closesocket(ConnectSocket);
				ConnectSocket = INVALID_SOCKET;
				continue;
			}
			break;
		}
	}

	freeaddrinfo(result);

	statusLogFile = statusLogOpen();
	eventLogFile = eventLogOpen();

	/* set heartbeat rate */
	PRINT_DBG("set heartbeat\n");
	if (setsockopt(ConnectSocket,
		SOL_SOCKET,
		SO_RCVTIMEO,
		(const char *)&socketTimeout,
		sizeof(socketTimeout)) != 0) {
		hResult = NS_E_INTERNAL_SERVER_ERROR;
		PRINT_DBG("mavenFileFilter - unable to set socket timeout\n");
		goto Main_Exit;
	}

	/* Send a connect message */
	PRINT_DBG("mavenFilefilter Send a connect message\n");
	iResult = send(ConnectSocket, FILEFILTER_ID_STRING VERSION_STRING, 
		(int)strlen(FILEFILTER_ID_STRING) + (int)strlen(VERSION_STRING) + 1, 0);
	if (iResult == SOCKET_ERROR) {
		hResult = NS_E_INTERNAL_SERVER_ERROR;
		PRINT_DBG("mavenFileFilter - send failed with error: %d\n", WSAGetLastError());
		goto Main_Exit;
	}
	Sleep(1000); /* let socket connect */
	PRINT_DBG("mavenFileFilter - Bytes Sent: %ld, 0x%x\n", iResult, hResult);

	/* process filter messages */
	hMessageProcess = CreateThread(NULL, 0, &messageProcessThread,
		NULL, 0, NULL);

	WaitForSingleObject(hStopEvent, INFINITE);
	PRINT_DBG("mavenFileFilter - hStopEvent\n");
Main_Exit:
	StopService();

	return hResult;
}

