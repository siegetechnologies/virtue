// filefilterService.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
/* Copyright(c) 2019 Siege Technologies, 1105 Floyd Avenue Rome, NY 13440

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files(the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions :

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/
#include "stdafx.h"

#define SLEEP_TIME 5000

#define MAVEN_DEBUG
#ifdef MAVEN_DEBUG
FILE  *svcLogFile = NULL;
#define PRINT_DBG(...) fprintf(svcLogFile, __VA_ARGS__); fflush(svcLogFile)
#define WPRINT_DBG(...) 
#else /* HIDDEN_CONSOLE */
#define PRINT_DBG(...)
#define WPRINT_DBG(...)
#endif

int mavenFilefilter(void);
void  ControlHandler(DWORD request);
void ServiceMain(int argc, char** argv);
int InitService();
extern HANDLE hStopEvent;

SERVICE_STATUS ServiceStatus;
SERVICE_STATUS_HANDLE hStatus;


int main()
{
	SERVICE_TABLE_ENTRY ServiceTable[2];
	ServiceTable[0].lpServiceName = (LPWSTR)L"mavenFilefilter";
	ServiceTable[0].lpServiceProc = (LPSERVICE_MAIN_FUNCTION)ServiceMain;

	ServiceTable[1].lpServiceName = NULL;
	ServiceTable[1].lpServiceProc = NULL;
#ifdef MAVEN_DEBUG
	fopen_s(&svcLogFile, "C:\\maven\\filefilterServiceLog.txt", "w");
#endif
	PRINT_DBG("filefilterService main()\n");
	// Start the control dispatcher thread for our service
	StartServiceCtrlDispatcher(ServiceTable);
}


void ServiceMain(int argc, char** argv)
{
	int error;

	ServiceStatus.dwServiceType = SERVICE_WIN32;
	ServiceStatus.dwCurrentState = SERVICE_START_PENDING;
	ServiceStatus.dwControlsAccepted = SERVICE_ACCEPT_STOP | SERVICE_ACCEPT_SHUTDOWN;
	ServiceStatus.dwWin32ExitCode = 0;
	ServiceStatus.dwServiceSpecificExitCode = 0;
	ServiceStatus.dwCheckPoint = 0;
	ServiceStatus.dwWaitHint = 0;

	hStatus = RegisterServiceCtrlHandler(
		(LPWSTR)L"MemoryStatus",
		(LPHANDLER_FUNCTION)ControlHandler);
	if (hStatus == (SERVICE_STATUS_HANDLE)0)
	{
		// Registering Control Handler failed
		PRINT_DBG("ServiceMain Registering Control Handler failed\n");
		return;
	}
	PRINT_DBG("ServiceMain Initialize Service\n");
	// Initialize Service 
	error = InitService();
	if (error)
	{
		PRINT_DBG("ServiceMain Initialization failed\n");
		// Initialization failed
		ServiceStatus.dwCurrentState = SERVICE_STOPPED;
		ServiceStatus.dwWin32ExitCode = -1;
		SetServiceStatus(hStatus, &ServiceStatus);
		return;
	}
	// We report the running status to SCM. 
	ServiceStatus.dwCurrentState = SERVICE_RUNNING;
	SetServiceStatus(hStatus, &ServiceStatus);

	SetCurrentDirectory(MAVEN_DIRECTORY_W);
	Sleep(1000);	/* give mavenWindows a chance to start */
	PRINT_DBG("ServiceMain calls mavenfilefilter\n");
	(void)mavenFilefilter();
	return;
}

// Service initialization
int InitService()
{
	PRINT_DBG("InitService \n");
	return 0;
}

// Control handler function
void ControlHandler(DWORD request)
{
	switch (request)
	{
	case SERVICE_CONTROL_STOP:
		PRINT_DBG("ControlHandler SERVICE_CONTROL_STOP\n");
		ServiceStatus.dwWin32ExitCode = 0;
		ServiceStatus.dwCurrentState = SERVICE_STOPPED;
		SetServiceStatus(hStatus, &ServiceStatus);
		SetEvent(hStopEvent); /* terminate all apps */
#ifdef MAVEN_DEBUG
		fclose(svcLogFile);
		svcLogFile = NULL;
#endif
		return;

	case SERVICE_CONTROL_SHUTDOWN:
		PRINT_DBG("ControlHandler SERVICE_CONTROL_SHUTDOWN\n");
		ServiceStatus.dwWin32ExitCode = 0;
		ServiceStatus.dwCurrentState = SERVICE_STOPPED;
		SetServiceStatus(hStatus, &ServiceStatus);
		SetEvent(hStopEvent); /* terminate all apps */
#ifdef MAVEN_DEBUG
		fclose(svcLogFile);
		svcLogFile = NULL;
#endif
		return;

	default:
		PRINT_DBG("ControlHandler %d \n", request);
		break;
	}

	PRINT_DBG("ControlHandler Report current status\n");
	// Report current status
	SetServiceStatus(hStatus, &ServiceStatus);

	return;
}
