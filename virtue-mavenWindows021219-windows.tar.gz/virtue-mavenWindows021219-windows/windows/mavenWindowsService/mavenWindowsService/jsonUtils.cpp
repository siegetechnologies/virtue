/*++

Module Name: jsonUtilson.cpp

Abstract:

This set of functions are used to parse and form messages in the JSON format.  Receive 
messages are parsed to identify request type and associated transducer.  The mavenClient 
app is queried for transducer state and a response message is formed and returned.

Revision History:
Author Richard Carter - Siege Technologies, Manchester NH

V1.1	03/15/2018 - REC, written
V1.2	08/15/2018 - REC, hide windows

--*/
/* Copyright(c) 2019 Siege Technologies, 1105 Floyd Avenue Rome, NY 13440

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files(the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions :

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/
#include "stdafx.h"

static char module_name[] = {"mavenWindowsService jsonUtils.cpp"};

#define MAVEN_DEBUG
#ifdef MAVEN_DEBUG
extern FILE  *dbgLogFile;
#define PRINT_DBG(...) if(dbgLogFile){fprintf(dbgLogFile, __VA_ARGS__); fflush(dbgLogFile);}
#define WPRINT_DBG(...) 
#else /* HIDDEN_CONSOLE */
#define PRINT_DBG(...)
#define WPRINT_DBG(...)
#endif

#define CONFIG_DEBUG
#ifdef CONFIG_DEBUG
#ifdef HIDDEN_CONSOLE
extern FILE  *dbgLogFile;
#define PRINT_CFG(...) fprintf(dbgLogFile, __VA_ARGS__)
#define WPRINT_CFG(...) wfprintf(dbgLogFile, __VA_ARGS__)
#else
#define PRINT_CFG(...) printf(__VA_ARGS__)
#define WPRINT_CFG(...) wprintf(__VA_ARGS__)
#endif
#else
#define PRINT_CFG(...)
#define WPRINT_CFG(...)
#endif

#ifdef HIDDEN_CONSOLE
int charToWide(WCHAR* dest, const CHAR* source);
#define ERR_STR_LEN CONSOLE_LINE_SIZE
void reportError(long errorLine, char *errorString, char *moduleName);
#define _ERROR(fmt,...) { char errorText[ERR_STR_LEN];  \
snprintf(errorText, ERR_STR_LEN, fmt, __VA_ARGS__); \
reportError(__LINE__, errorText, module_name); }
#else
#define _ERROR(fmt,...) fprintf(stderr,  "%s line %d " fmt, module_name, __LINE__, __VA_ARGS__)
#endif
/* command enumeration from C&C*/
#define CNC_INVALID 0
#define	CNC_ENABLE_FILEFILTER 1
#define	CNC_ENABLE_NETFILTER 2
#define CNC_DISABLE_FILEFILTER 3
#define	CNC_DISABLE_NETFILTER 4
#define	CNC_GET_ENABLE_FILEFILTER 5
#define	CNC_GET_ENABLE_NETFILTER 6
#define	CNC_GET_CONFIG_FILEFILTER 7
#define	CNC_GET_CONFIG_NETFILTER 8
#define CNC_LIST_ENABLED 9

/* strings used to parse C&C commands */
#define CNC_CMD_ENABLE "enable"
#define CNC_CMD_DISABLE "disable"
#define CNC_CMD_GET_ENABLE "get enable"
#define CNC_CMD_GET_CONFIG "get configuration"
#define CNC_CMD_LIST_ENABLED "list enabled"

/* strings ID C&C commands */
#define CNC_KEY_CMD_ENABLE 0
#define CNC_KEY_CMD_DISABLE 1
#define CNC_KEY_CMD_GET_ENABLE 2
#define CNC_KEY_CMD_GET_CONFIG 3
#define CNC_KEY_CMD_LIST_ENABLED 4

#define CNC_NUM_CMDS 5
static const char *CnCCmds[CNC_NUM_CMDS] = {
	CNC_CMD_ENABLE,
	CNC_CMD_DISABLE,
	CNC_CMD_GET_ENABLE,
	CNC_CMD_GET_CONFIG,
	CNC_CMD_LIST_ENABLED,
};

#define CNC_CMD_FILEFILTER "fileFilter"
#define CNC_CMD_NETFILTER "netFilter"
#define NUM_TRANSDUCERS 2


static const char *transducer[NUM_TRANSDUCERS] = {
	CNC_CMD_FILEFILTER,
	CNC_CMD_NETFILTER
};

/* outgoing C&C JSON message fragments */
#define JSON_ENABLE "\"enable\": "
#define JSON_GET_ENABLE "\"get enable\": "
#define JSON_GET_CONFIG "\"get configuration\": "
#define JSON_LIST_ENABLED "\"list enabled\": "
#define JSON_DISABLE "\"disable\": "
#define JSON_NAME "{\"name\": "
#define JSON_FILEFILTER "\"fileFilter\", "
#define JSON_NETFILTER "\"netFilter\", "
#define JSON_STATUS "\"status\" : "
#define JSON_CLOSEBRACES "} }\n"
#define JSON_SUCCESS "\"success\"" JSON_CLOSEBRACES
#define JSON_TRUE "\"true\"" JSON_CLOSEBRACES
#define JSON_FALSE "\"false\"" JSON_CLOSEBRACES
#define JSON_ERROR "\"ERROR\"" JSON_CLOSEBRACES
#define JSON_CONFIG "\"config\" : "
#define JSON_NEITHER "\"[]\"" JSON_CLOSEBRACES
#define JSON_FF "\"[fileFilter]\"" JSON_CLOSEBRACES
#define JSON_NF "\"[netFilter]\"" JSON_CLOSEBRACES
#define JSON_BOTH "\"[fileFilter, netFilter]\"" JSON_CLOSEBRACES



void transducerSetMode(int transducer, OPERATING_MODE mode); /* sets filter mode if enable, else idle */
BOOL transducerError(int transducer);	/* returns true if unreachable */
BOOL transducerEnabled(int transducer);	/* returns true if filter mode */
char *transducerGetConfig(int transducer);	/* returns filter configuration */
BOOL transducerSetConfig(int transducer, char *config, size_t length);	/* sets filter configuration */
void transducerSetConfigFile(int transducer, char *path);

extern int wideToChar(CHAR* dest, const WCHAR* source);
extern char instanceId[CONSOLE_LINE_SIZE];
extern void instanceIdGet(void);

static long lastLine = 0;
static long lastErrorLine = 0;
static int numErrors = 0;
#define MAX_ERRORS 256

/***************************************************************************
* Name: systemInfoGet
*
* Routine Description: This function obtains the EC2 instance Id.  It 
*	formats the passed string as an incomplete fluentd 
*   message in JSON format, example below
*		{"ID" : "i-0d9a4e4bfcb23f195", 
*
* Returns: Size of returned string
*
**************************************************************************/
int systemInfoGet(
	int bufSize,	/* size of passed buffer */
	char *buf		/* return buffer */
)
{
	/* if instance ID is invalid */
	if (instanceId[0] != 'i')
	{
		instanceIdGet();
	}
	if (instanceId[0] != 'i')
	{
		return sprintf_s(buf, bufSize, "{\"ID\" : \"Unresolved ID\", ");
	}
	return sprintf_s(buf, bufSize, "{\"ID\" : \"%s\", ", instanceId);
}

/***************************************************************************
* Name: removeNewline
*
* Routine Description: This function removes newlines found in the input
*   string.  Any found are replaced by a space.
*
* Returns:  N/A
*
**************************************************************************/
void removeNewline(CHAR* source)
{
	int i = 0;

	while (source[i] != '\0') {
		if (source[i] == '\n')
			source[i] = ' ';
		i++;
	};
}

/***************************************************************************
* Name: reportError
*
* Routine Description: This function formats an error message and spawns
*	a thread to report the error.
*
* Returns: N/A
*
**************************************************************************/
void reportError(
	long errorLine,
	char *errorString,
	char *moduleName)
{
	/* prevent repetitive error reports */
	if ((lastErrorLine == errorLine) || (numErrors > MAX_ERRORS))
	{
		return;
	}
	else
	{
		char fluentdMsg[PAYLOAD_MSG_SZ];
		int i;

		numErrors++;
		lastErrorLine = errorLine;

		i = systemInfoGet(PAYLOAD_MSG_SZ, fluentdMsg);
		if (i < 0)
			return;
		removeNewline(errorString); /* fluentd doesn't like newlines in text*/
		sprintf_s(&fluentdMsg[i], PAYLOAD_MSG_SZ - i, "\"ERROR TEXT\" : \"%s line %d %s\"}\n", moduleName, errorLine, errorString);
		fluentdMsg[PAYLOAD_MSG_SZ - 1] = '\0';	/* force termination */
		PRINT_DBG("%s",fluentdMsg);
#ifndef HIDDEN_CONSOLE
		printf("%s\n", fluentdMsg);
#else
		if (FluentDSocket != INVALID_SOCKET)
		{
			int msgLen, iResult, WsaError;
			msgLen = static_cast<int>(strlen(fluentdMsg));
			iResult = send(FluentDSocket, fluentdMsg, msgLen, 0);

			if (iResult == SOCKET_ERROR)
			{
				WsaError = WSAGetLastError();
				_ERROR("FluentDSocket send failure %ld\n", WsaError);

				/* if port closed */
				if (WsaError == WSAENOTSOCK)
				{
					FluentDSocket = INVALID_SOCKET;
				}
			}
		}
#endif
	}
}

/***************************************************************************
* Name: parseGetToken
*
* Routine Description: This function parses a message buffer and returns an
*	index to the next JSON keyword.  Keywords are delimted by quotation marks.
*	Whatever is between the two quotes is assumed to be the keyword.
*	Keywords must be terminated by semicolons ':'.
*
* Returns: Index of next character after the second quote or zero if error.
*
**************************************************************************/
size_t parseGetToken(
	char *recvbuf,		/* string to parse */
	size_t	index,			/* index to start looking */
	size_t *firstQuote,	/* output - index of first quote */
	size_t *secondQuote	/* output - index of second quote */
)
{
	size_t strIndex = index;
	while (recvbuf[strIndex] != '\0')
	{
		/* find quotes */
		if (recvbuf[strIndex] == '"')
		{
			if (*firstQuote == 0)
			{
				*firstQuote = strIndex;
			}
			else
			{
				if (*secondQuote == 0)
				{
					*secondQuote = strIndex;
				}
				else
				{
					return 0; /* parse error */
				}
			}
		}
		/* find semicolon, comma, or close brace to end token */
		if ((*secondQuote != 0) &&
			((recvbuf[strIndex] == ':') || (recvbuf[strIndex] == ',') || (recvbuf[strIndex] == '}')))
		{
			if (*secondQuote != 0)
			{
				return strIndex;
			}
			return 0;	/* parse error */
		}

		strIndex++;
	}
	return 0;	/* parse error */

}

/***************************************************************************
* Name: parseGetKeyword
*
* Routine Description: This function parses messages received from the CnC
*	port and searches for a keyword.
*
* Returns: pointer to the argument described by keyword or NULL if not found
*
**************************************************************************/
char *parseGetKeyword(
	char *recvbuf, 
	size_t *index, 
	size_t *pSourceLen, 
	const char *keyword
)
{
	size_t firstQuote = 0;
	size_t secondQuote = 0;

	/* start looking for next token delimted by quotes */
	*index = parseGetToken(recvbuf, *index + 1, &firstQuote, &secondQuote);

	if (*index == 0)
	{
		return NULL; /* parse error */
	}

	/* compute length of token we found */
	*pSourceLen = secondQuote - firstQuote - 1;

	if (*pSourceLen != strlen(keyword))
	{
		return NULL; /* parse error */
	}

	/* token should be keyword */
	if ((strncmp(&recvbuf[firstQuote + 1], keyword, strlen(keyword) != 0)))
	{
		return NULL; /* parse error */
	}

	/* start looking for next token delimted by quotes */
	firstQuote = secondQuote = 0;
	*index = parseGetToken(recvbuf, *index + 1, &firstQuote, &secondQuote);

	/* compute length of token we found */
	*pSourceLen = secondQuote - firstQuote - 1;

	if (*pSourceLen <= 0)
	{
		return NULL; /* parse error */
	}
	return &recvbuf[firstQuote + 1];
}

/***************************************************************************
* Name: strIndexParseForConfiguration
*
* Routine Description: This function parses messages received from the CnC
*	port and returns the configuration string or NULL if not found.
*
* Returns: transducer index or NULL if error
*
**************************************************************************/
char *strIndexParseForConfiguration(char *recvbuf, size_t *pSourceLen, size_t *pIndex)
{
	char *config;
	config = parseGetKeyword(recvbuf, pIndex, pSourceLen, "config");
	if (config != NULL)
	{
		config -= 1;		/* back up and return first quote */
		*pSourceLen += 2;	/* string includes two quotes */
	}
	return config;
}


/***************************************************************************
* Name: strIndexParseForName
*
* Routine Description: This function parses messages received from the CnC
*	port and returns the transducer index.
*
* Returns: transducer index or -1 if error
*
**************************************************************************/
int strIndexParseForName(char *recvbuf, size_t *pIndex)
{
	int i;
	size_t strIndex = *pIndex;
	size_t sourceLen;
	char *name;

	name = parseGetKeyword(recvbuf, pIndex, &sourceLen, "name");

	/* we should now have a transducer name to parse, find it */
	for (i = 0; i < NUM_TRANSDUCERS; i++)
	{
		size_t cmdLen;
		cmdLen = strlen(transducer[i]);
		if (sourceLen != cmdLen)
		{
			continue;
		}
		if (strncmp(name, transducer[i], sourceLen) == 0)
		{
			break;	/* found command */
		}
	}

	if (i == NUM_TRANSDUCERS)
	{
		return -1; /* parse error, command not fund */
	}
	return i;
}

/***************************************************************************
* Name: parseGetCommand
*
* Routine Description: This function parses messages received from the CnC
*	port and returns the enumerated command type.
*
* Returns: CnC command
*
**************************************************************************/
int parseGetCommand(
	char *recvbuf,			/* pointer to receive buffer to parse */
	char **ppConfiguration,	/* return pointer to configuration string or NULL */
	size_t *pConfigLen		/* length of configuration string. */
)
{
	int cmd, transducer;
	size_t strIndex = 1;
	size_t firstQuote = 0;
	size_t secondQuote = 0;
	int rturnVal = CNC_INVALID;
	size_t sourceLen;

	*pConfigLen = 0;

	if (recvbuf[0] != '{')
	{
		return 0; /* not JSON */
	}
	strIndex = parseGetToken(recvbuf, strIndex, &firstQuote, &secondQuote);

	if (strIndex == 0)
	{
		return 0; /* parse error */
	}

	/* compute length of command we found */
	sourceLen = secondQuote - firstQuote - 1;

	if (sourceLen <= 0)
	{
		return 0; /* parse error */
	}

	PRINT_CFG("parseGetCommand - cmd = %s\n", &recvbuf[firstQuote + 1]);
	/* we should now have a command to parse, find it */
	for (cmd = 0; cmd < CNC_NUM_CMDS; cmd++)
	{
		size_t cmdLen;
		cmdLen = strlen(CnCCmds[cmd]);
		if (sourceLen != cmdLen)
		{
			continue;
		}
		if (strncmp(&recvbuf[firstQuote + 1], CnCCmds[cmd], sourceLen) == 0)
		{
			break;	/* found command */
		}
	}

	if (cmd == CNC_NUM_CMDS)
	{
		return 0; /* parse error, command not fund */
	}

	/* at this point, we found a command.  Some command require parsing of arguments */
	if (cmd != CNC_KEY_CMD_LIST_ENABLED)
	{
		transducer = strIndexParseForName(recvbuf, &strIndex);
		PRINT_CFG("parseGetCommand - finds transducer %d\n", transducer);
		if (transducer < 0)
		{
			return 0; /* parse error, transducer not found */
		}
	}
	/* the enable and disable commands may have an optional configuration argument */
	if ((cmd == CNC_KEY_CMD_ENABLE) || (cmd == CNC_KEY_CMD_DISABLE) || (cmd == CNC_KEY_CMD_GET_CONFIG))
	{
		*ppConfiguration = strIndexParseForConfiguration(recvbuf, pConfigLen, &strIndex);
	}


	switch (cmd)
	{
	case CNC_KEY_CMD_ENABLE:
		return CNC_ENABLE_FILEFILTER + transducer;
	case CNC_KEY_CMD_DISABLE:
		return CNC_DISABLE_FILEFILTER + transducer;
	case CNC_KEY_CMD_GET_ENABLE:
		return CNC_GET_ENABLE_FILEFILTER + transducer;
	case CNC_KEY_CMD_GET_CONFIG:
		return CNC_GET_CONFIG_FILEFILTER + transducer;
	case CNC_KEY_CMD_LIST_ENABLED:
		return CNC_LIST_ENABLED;
	}

	_ERROR("parseGetCommand - parses invalid command\n");

	return 0; /* parse error, transducer not found */
}
/***************************************************************************
* Name: parseCncMessage
*
* Routine Description: This function parses messages received from the CnC
*	port and returns a formatted response message in the same passed buffer.
*	If unable to parse the message, the input buffer remains unchanged.
*
* Returns: FALSE if able to parse message, otherwise TRUE
*
**************************************************************************/
BOOL parseCncMessage(char *buf)
{
	int cncCmd;
	int i;
	BOOL netfilterEnabled, filefilterEnabled;
	char *pString;
	char * pConfig = NULL;
	char sucessString[] = { JSON_SUCCESS };
	char errorString[] = { JSON_ERROR };
	char trueString[] = { JSON_TRUE };
	char falseString[] = { JSON_FALSE };
	char neitherString[] = { JSON_NEITHER };
	char filefilterString[] = { JSON_FF };
	char netfilterString[] = { JSON_NF };
	char bothString[] = { JSON_BOTH };
	size_t configLength = 0;
	BOOL configError = FALSE;

	PRINT_DBG("parseCncMessage  \"%s\"\n", buf);
	/* parse the C&C nessage */
	cncCmd = parseGetCommand(buf, &pConfig, &configLength);
	PRINT_DBG("parseCncMessage  command = %d\n", cncCmd);


	switch (cncCmd)
	{
	case CNC_INVALID:
		/* invalid command */
		_ERROR("parseCncMessage - processes invalid command \n");
		break;
	case CNC_ENABLE_FILEFILTER:
		pString = errorString;
		if (transducerError(TRANSDUCER_FILEFILTER))
		{
			_ERROR("parseCncMessage - filefilter bad socket \n");
			break;
		}
		if ((pConfig != NULL) && (pConfig[0] == '"'))
		{
			PRINT_DBG("parseCncMessage  download the whitelist\n");
			/* download the whitelist and set the mode to filter */
			if (!transducerSetConfig(TRANSDUCER_FILEFILTER, pConfig, configLength))
			{
				_ERROR("parseCncMessage - **** unable to set filefilter configuration \n");
				configError = TRUE;
			}
		}
		else
		{
			/* set the mode of the filefilter */
			transducerSetMode(TRANSDUCER_FILEFILTER, MAVEN_FILTER);
		}
		/* verify that the filter is in the expected mode */
		if ((!configError) && (transducerEnabled(TRANSDUCER_FILEFILTER)))
		{
			PRINT_CFG("parseCncMessage - filefilter enabled filter \n");
			pString = sucessString;
		}
		i = systemInfoGet(PAYLOAD_MSG_SZ, buf);
		if (i < 0)
		{
			_ERROR("parseCncMessage - unable to get system information \n");
			break;
		}
		snprintf(&buf[i], PAYLOAD_MSG_SZ, JSON_ENABLE JSON_NAME
			JSON_FILEFILTER JSON_STATUS "%s", pString);
		break;
	case CNC_ENABLE_NETFILTER:
		pString = errorString;
		if (!transducerError(TRANSDUCER_NETFILTER))
		{
			if (pConfig != NULL)
			{
				(void)transducerSetConfig(TRANSDUCER_NETFILTER, pConfig, configLength);
			}
			/* set the mode of the netFilter */
			transducerSetMode(TRANSDUCER_NETFILTER, MAVEN_FILTER);

			/* verify that the filter is in filter mode */
			if (transducerEnabled(TRANSDUCER_NETFILTER))
			{
				PRINT_CFG("parseCncMessage - netfilter enabled filter \n");
				pString = sucessString;
			}
		}
		i = systemInfoGet(PAYLOAD_MSG_SZ, buf);
		if (i < 0)
		{
			_ERROR("parseCncMessage - unable to get system information \n");
			break;
		}
		snprintf(&buf[i], PAYLOAD_MSG_SZ, JSON_ENABLE JSON_NAME
			JSON_NETFILTER JSON_STATUS "%s", pString);
		break;
	case CNC_DISABLE_FILEFILTER:
		if (transducerError(TRANSDUCER_FILEFILTER))
		{
			_ERROR("parseCncMessage - filefilter bad socket \n");
			pString = errorString;
		}
		else
		{
			/* set the mode of the filefilter */
			/* the filefilter is a special case.  When disabling, you can set learn mode as an option*/
			if ((pConfig != NULL) && ((pConfig[1] == 'l') || (pConfig[1] == 'L')))
			{
				transducerSetMode(TRANSDUCER_FILEFILTER, MAVEN_LEARN);
			}
			else
			{
				transducerSetMode(TRANSDUCER_FILEFILTER, MAVEN_IDLE);
			}

			/* verify that the filter is in the expected mode */
			if (!transducerEnabled(TRANSDUCER_FILEFILTER))
			{
				pString = sucessString;
			}
			else
			{
				pString = errorString;
			}

		}
		i = systemInfoGet(PAYLOAD_MSG_SZ, buf);
		if (i < 0)
		{
			_ERROR("parseCncMessage - unable to get system information \n");
			break;
		}
		snprintf(&buf[i], PAYLOAD_MSG_SZ, JSON_DISABLE JSON_NAME
			JSON_FILEFILTER JSON_STATUS "%s", pString);
		break;
	case CNC_DISABLE_NETFILTER:
		pString = errorString;
		if (!transducerError(TRANSDUCER_NETFILTER))
		{
			/* set the mode of the netFilter */
			transducerSetMode(TRANSDUCER_NETFILTER, MAVEN_IDLE);
			/* verify that the filter is in the expected mode */
			if (!transducerEnabled(TRANSDUCER_NETFILTER))
			{
				pString = sucessString;
			}
		}
		i = systemInfoGet(PAYLOAD_MSG_SZ, buf);
		if (i < 0)
		{
			_ERROR("parseCncMessage - unable to get system information \n");
			break;
		}
		snprintf(&buf[i], PAYLOAD_MSG_SZ, JSON_DISABLE JSON_NAME
			JSON_NETFILTER JSON_STATUS "%s", pString);
		break;
	case CNC_GET_ENABLE_FILEFILTER:
		if (transducerError(TRANSDUCER_FILEFILTER))
		{
			_ERROR("parseCncMessage - filefilter bad socket \n");
			pString = errorString;
		}
		else
		{
			/* get the filter mode */
			if (transducerEnabled(TRANSDUCER_FILEFILTER))
			{
				pString = trueString;
			}
			else
			{
				pString = falseString;
			}
		}
		i = systemInfoGet(PAYLOAD_MSG_SZ, buf);
		if (i < 0)
		{
			_ERROR("parseCncMessage - unable to get system information \n");
			break;
		}
		snprintf(&buf[i], PAYLOAD_MSG_SZ, JSON_GET_ENABLE JSON_NAME
			JSON_FILEFILTER JSON_STATUS "%s", pString);
		break;
	case CNC_GET_ENABLE_NETFILTER:
		if (transducerError(TRANSDUCER_NETFILTER))
		{
			_ERROR("parseCncMessage - netfilter bad socket \n");
			pString = errorString;
		}
		else
		{
			/* get the filter mode */
			if (transducerEnabled(TRANSDUCER_NETFILTER))
			{
				pString = trueString;
			}
			else
			{
				pString = falseString;
			}
		}
		i = systemInfoGet(PAYLOAD_MSG_SZ, buf);
		if (i < 0)
		{
			_ERROR("parseCncMessage - unable to get system information \n");
			break;
		}
		snprintf(&buf[i], PAYLOAD_MSG_SZ, JSON_GET_ENABLE JSON_NAME
			JSON_NETFILTER JSON_STATUS "%s", pString);
		break;
	case CNC_GET_CONFIG_FILEFILTER:
		if ((transducerError(TRANSDUCER_FILEFILTER)) || (transducerEnabled(TRANSDUCER_FILEFILTER)))
		{
			_ERROR("parseCncMessage - filefilter bad socket or bad state \n");
			i = systemInfoGet(PAYLOAD_MSG_SZ, buf);
			if (i < 0)
			{
				_ERROR("parseCncMessage - unable to get system information \n");
				break;
			}
			snprintf(&buf[i], PAYLOAD_MSG_SZ, JSON_GET_CONFIG JSON_NAME
				JSON_FILEFILTER JSON_STATUS "%s", errorString);
		}
		else
		{
			/* if passed file name argument */
			if (pConfig != NULL)
			{
				pConfig[configLength - 1] = '\0'; /* overwrite last quote, terminate file name string */
				PRINT_CFG("parseCncMessage - pConfig = %s\n", pConfig);
				transducerSetConfigFile(TRANSDUCER_FILEFILTER, pConfig);
			}
			pConfig = transducerGetConfig(TRANSDUCER_FILEFILTER);

			if (pConfig == NULL)
			{
				i = systemInfoGet(PAYLOAD_MSG_SZ, buf);
				if (i < 0)
				{
					_ERROR("parseCncMessage - unable to get system information \n");
					break;
				}
				snprintf(&buf[i], PAYLOAD_MSG_SZ, JSON_DISABLE JSON_NAME
					JSON_NETFILTER JSON_STATUS JSON_ERROR);
			}
			else
			{
				i = systemInfoGet(PAYLOAD_MSG_SZ, buf);
				if (i < 0)
				{
					_ERROR("parseCncMessage - unable to get system information \n");
					break;
				}
				snprintf(&buf[i], PAYLOAD_MSG_SZ, JSON_GET_CONFIG JSON_NAME
					JSON_FILEFILTER JSON_CONFIG "\"%s\"" JSON_CLOSEBRACES, pConfig);
			}
		}
		break;
	case CNC_GET_CONFIG_NETFILTER:
		pConfig = transducerGetConfig(TRANSDUCER_NETFILTER);
		if (transducerError(TRANSDUCER_NETFILTER))
		{
			_ERROR("parseCncMessage - netfilter bad socket \n");
			pConfig = errorString;
		}
		else if (pConfig == NULL)
		{
			i = systemInfoGet(PAYLOAD_MSG_SZ, buf);
			if (i < 0)
			{
				_ERROR("parseCncMessage - unable to get system information \n");
				break;
			}
			snprintf(&buf[i], PAYLOAD_MSG_SZ, JSON_GET_CONFIG JSON_NAME
				JSON_NETFILTER JSON_CONFIG "null " JSON_CLOSEBRACES);
		}
		else
		{
			i = systemInfoGet(PAYLOAD_MSG_SZ, buf);
			if (i < 0)
			{
				_ERROR("parseCncMessage - unable to get system information \n");
				break;
			}
			snprintf(&buf[i], PAYLOAD_MSG_SZ, JSON_GET_CONFIG JSON_NAME
				JSON_NETFILTER JSON_CONFIG "\"%s\"" JSON_CLOSEBRACES, pConfig);

		}
		break;
	case CNC_LIST_ENABLED:
		/* here we have four choices for a return string, neither, 
			just netFilter, just filefilter, or both */
		if (transducerError(TRANSDUCER_NETFILTER))
		{
			_ERROR("parseCncMessage - netfilter bad socket \n");
			netfilterEnabled = FALSE;
		}
		else
		{
			/* get the filter mode */
			netfilterEnabled = transducerEnabled(TRANSDUCER_NETFILTER);
		}
		if (transducerError(TRANSDUCER_FILEFILTER))
		{
			_ERROR("parseCncMessage - filefilter bad socket \n");
			filefilterEnabled = FALSE;
		}
		else
		{
			/* get the filter mode */
			filefilterEnabled = transducerEnabled(TRANSDUCER_FILEFILTER);
		}

		pString = bothString;
		if (!netfilterEnabled && !filefilterEnabled)
			pString = neitherString;
		if (netfilterEnabled && !filefilterEnabled)
			pString = netfilterString;
		if (!netfilterEnabled && filefilterEnabled)
			pString = filefilterString;

		i = systemInfoGet(PAYLOAD_MSG_SZ, buf);
		if (i < 0)
		{
			_ERROR("parseCncMessage - unable to get system information \n");
			break;
		}
		snprintf(&buf[i], PAYLOAD_MSG_SZ, JSON_LIST_ENABLED JSON_NAME
			"%s", pString);
		break;
	default:
		PRINT_CFG("parseCncMessage - unable to parse\n");
		return TRUE;
	}

	PRINT_CFG("parseCncMessage - returns %s \n", buf);
	return FALSE;
}
