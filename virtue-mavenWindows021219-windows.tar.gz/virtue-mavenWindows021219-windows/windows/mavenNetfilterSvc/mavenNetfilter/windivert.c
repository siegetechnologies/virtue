/*
 * windivert.c
 * (C) 2016, all rights reserved,
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef UNICODE
#define UNICODE
#endif

#include "stdafx.h"

#include <winsock2.h>
#include <windows.h>
#include <winioctl.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>

#ifdef MAVEN_DEBUG
#if (defined HIDDEN_CONSOLE) || (defined MAVEN_SERVICE)
FILE  *dbgLogFile = NULL;
#define PRINT_DBG(...) if (dbgLogFile){fprintf(dbgLogFile, __VA_ARGS__); fflush(dbgLogFile);}
#define WPRINT_DBG(...) 
#else
#define PRINT_DBG(...) printf(__VA_ARGS__)
#define WPRINT_DBG(...) wprintf(__VA_ARGS__)
#endif
#else /* HIDDEN_CONSOLE */
#define PRINT_DBG(...)
#define WPRINT_DBG(...)
#endif

#define WINDIVERTEXPORT

#define WINDIVERT_DRIVER_NAME           L"WinDivert"
#define WINDIVERT_DRIVER32_SYS          L"\\WinDivertDrv.sys"
#define WINDIVERT_DRIVER64_SYS          L"\\WinDivertDrv.sys"

/*
 * Definitions to remove (some) external dependencies:
 */
#define BYTESWAP16(x)                   \
    ((((x) >> 8) & 0x00FF) | (((x) << 8) & 0xFF00))
#define BYTESWAP32(x)                   \
    ((((x) >> 24) & 0x000000FF) | (((x) >> 8) & 0x0000FF00) | \
     (((x) << 8) & 0x00FF0000) | (((x) << 24) & 0xFF000000))
#define ntohs(x)                        BYTESWAP16(x)
#define htons(x)                        BYTESWAP16(x)
#define ntohl(x)                        BYTESWAP32(x)
#define htonl(x)                        BYTESWAP32(x)

static char module_name[] = { "windivert.c" };

static BOOLEAN WinDivertStrLen(const wchar_t *s, size_t maxlen,
    size_t *lenptr);
static BOOLEAN WinDivertStrCpy(wchar_t *dst, size_t dstlen,
    const wchar_t *src);
static BOOLEAN WinDivertAToI(const char *str, char **endptr, UINT32 *intptr);
static BOOLEAN WinDivertAToX(const char *str, char **endptr, UINT32 *intptr);

/*
 * IPv4/IPv6 pseudo headers.
 */
typedef struct
{
    UINT32 SrcAddr;
    UINT32 DstAddr;
    UINT8  Zero;
    UINT8  Protocol;
    UINT16 Length;
} WINDIVERT_PSEUDOHDR, *PWINDIVERT_PSEUDOHDR;

typedef struct
{
    UINT32 SrcAddr[4];
    UINT32 DstAddr[4];
    UINT32 Length;
    UINT32 Zero:24;
    UINT32 NextHdr:8;
} WINDIVERT_PSEUDOV6HDR, *PWINDIVERT_PSEUDOV6HDR;


/*
 * Misc.
 */
#ifndef UINT8_MAX
#define UINT8_MAX       0xFF
#endif
#ifndef UINT32_MAX
#define UINT32_MAX      0xFFFFFFFF
#endif

/*
 * Prototypes.
 */
static BOOLEAN WinDivertUse32Bit(void);
static BOOLEAN WinDivertGetDriverFileName(LPWSTR sys_str);
static SC_HANDLE WinDivertDriverInstall(VOID);
static BOOL WinDivertIoControl(HANDLE handle, DWORD code, UINT8 arg8,
    UINT64 arg, PVOID buf, UINT len, UINT *iolen);
static BOOL WinDivertIoControlEx(HANDLE handle, DWORD code, UINT8 arg8,
    UINT64 arg, PVOID buf, UINT len, UINT *iolen, LPOVERLAPPED overlapped);
static UINT8 WinDivertSkipExtHeaders(UINT8 proto, UINT8 **header, UINT *len);

#ifdef WINDIVERT_DEBUG
static void WinDivertFilterDump(windivert_ioctl_filter_t filter, UINT16 len);
#endif

/*
 * Include the helper API implementation.
 */
#include "windivert_helper.c"

HANDLE driverHandle = INVALID_HANDLE_VALUE;

/*
 * Thread local.
 */
static DWORD windivert_tls_idx;

/*
 * Current DLL hmodule.
 */
static HMODULE module = NULL;

#ifdef HIDDEN_CONSOLE
static long lastErrorLine = 0;
static int numErrors = 0;
#define MAX_ERRORS 256

/***************************************************************************
* Name: reportError
*
* Routine Description: This function formats an error message and spawns
*	a thread to report the error.
*
* Returns: N/A
*
**************************************************************************/
void reportError(
	long errorLine,
	char *errorString,
	char *moduleName)
{
	char errorText[ERR_STR_LEN];
	/* prevent repetitive error reports */
	if ((lastErrorLine == errorLine) || (numErrors > MAX_ERRORS))
	{
		return;
	}
	else
	{
		int iResult;
		numErrors++;
		lastErrorLine = errorLine;
		snprintf(errorText, ERR_STR_LEN, "NetFilter error %s line %d %s", moduleName, errorLine, errorString);
		if (ConnectSocket != INVALID_SOCKET)
		{
			PRINT_DBG("**** ERROR %s\n", errorText);
		}
		else
		{
			PRINT_DBG("**** ERROR socket error \n");
			return; /* don't log events if there's noplace to send them */
		}
		iResult = send(ConnectSocket, errorText,
			(int)strlen(errorText) + 1, 0);
		if (iResult == SOCKET_ERROR)
		{
			PRINT_DBG("send failed with error: %d\n", WSAGetLastError());
		}


	}
}
#endif

/*
 * Test if we should use the 32-bit or 64-bit driver.
 */
static BOOLEAN WinDivertUse32Bit(void)
{
    BOOL is_wow64;

    if (sizeof(void *) == sizeof(UINT64))
    {
        return FALSE;
    }
    if (!IsWow64Process(GetCurrentProcess(), &is_wow64))
    {
        // Just guess:
        return FALSE;
    }
    return (is_wow64? FALSE: TRUE);
}

/*
 * Locate the WinDivert driver files.
 */
static BOOLEAN WinDivertGetDriverFileName(LPWSTR sys_str)
{
    size_t dir_len, sys_len;
    BOOLEAN is_32bit;

    is_32bit = WinDivertUse32Bit();

    if (is_32bit)
    {
        if (!WinDivertStrLen(WINDIVERT_DRIVER32_SYS, MAX_PATH, &sys_len))
        {
            SetLastError(ERROR_BAD_PATHNAME);
            return FALSE;
        }
    }
    else
    {
        if (!WinDivertStrLen(WINDIVERT_DRIVER64_SYS, MAX_PATH, &sys_len))
        {
            SetLastError(ERROR_BAD_PATHNAME);
            return FALSE;
        }
    }

    dir_len = (size_t)GetModuleFileName(module, sys_str, MAX_PATH);
    if (dir_len == 0)
    {
        return FALSE;
    }
    for (; dir_len > 0 && sys_str[dir_len] != L'\\'; dir_len--)
        ;
    if (sys_str[dir_len] != L'\\' || dir_len + sys_len + 1 >= MAX_PATH)
    {
        SetLastError(ERROR_BAD_PATHNAME);
        return FALSE;
    }
    if (!WinDivertStrCpy(sys_str + dir_len, MAX_PATH-dir_len-1,
            (is_32bit? WINDIVERT_DRIVER32_SYS: WINDIVERT_DRIVER64_SYS)))
    {
        SetLastError(ERROR_BAD_PATHNAME);
        return FALSE;
    }

    return TRUE;
}

#define MAX_RETRIES (NETFILTER_STARTUP_TIMEOUT * 10)
/*
 * Install the WinDivert driver.
 */
static SC_HANDLE WinDivertDriverInstall(VOID)
{
    DWORD err, retries = 0;
    SC_HANDLE manager = NULL, service = NULL;
    SERVICE_STATUS status;
#ifndef USE_INSTALLED_DRIVER  /* service installed as driver */
	wchar_t windivert_sys[MAX_PATH + 1];
#endif

	PRINT_DBG("WinDivertDriverInstall\n");
	// Open the service manager:
    manager = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
    if (manager == NULL)
    {
		PRINT_DBG(" unable to open SCManager\n");
		goto WinDivertDriverInstallExit;
    }

#ifdef USE_INSTALLED_DRIVER  /* service installed as driver */
	while ((retries < MAX_RETRIES) && (service == NULL))
	{
		service = OpenService(manager, WINDIVERT_DEVICE_NAME, SERVICE_ALL_ACCESS);
		Sleep(100);
		retries++;
	}
#else 
	// Check if the WinDivert service already exists; if so, start it.
WinDivertDriverInstallReTry:
	service = OpenService(manager, WINDIVERT_DEVICE_NAME, SERVICE_ALL_ACCESS);
	if (service != NULL)
	{
		PRINT_DBG(" WinDivertDriverInstall already exists\n");
		goto WinDivertDriverInstallExit;

	}

	// Get driver file:
	if (!WinDivertGetDriverFileName(windivert_sys))
	{
		goto WinDivertDriverInstallExit;
	}

	WPRINT_DBG(L" opening (%d) %ls\n", retries, windivert_sys);
	// Create the service:
	service = CreateService(manager, WINDIVERT_DEVICE_NAME,
		WINDIVERT_DEVICE_NAME, SERVICE_ALL_ACCESS, SERVICE_KERNEL_DRIVER,
		SERVICE_DEMAND_START, SERVICE_ERROR_NORMAL, windivert_sys, NULL, NULL,
		NULL, NULL, NULL);

	if (service != NULL)
    {
		PRINT_DBG(" WinDivertDriverInstall already exists\n");
		goto WinDivertDriverInstallExit;
  
	}

    if (service == NULL)
    {
        if (GetLastError() == ERROR_SERVICE_EXISTS) 
        {
            if (retries != 0)
            {
                retries--;
                goto WinDivertDriverInstallReTry;
            }
        }
        goto WinDivertDriverInstallExit;
    }
#endif

WinDivertDriverInstallExit:

	if (service != NULL)
	{
		BOOL started = FALSE;
		PRINT_DBG(" WinDivertDriverInstall StartService, %d retries\n", retries);

		// Start the service:

		while (!started && (retries < MAX_RETRIES) )
		{
			started = StartService(service, 0, NULL);
			if (!started)
			{
				err = GetLastError();
				if (err == ERROR_SERVICE_ALREADY_RUNNING)
				{
					PRINT_DBG(" WinDivertDriverInstall already running\n");
					SetLastError(0);
					started = TRUE;
					break;
				}
				retries++;
				Sleep(100);
			}
		}

		if (!started)
        {
            // Failed to start service; clean-up:
			_ERROR(" WinDivertDriverInstall failed to start service %d\n", err);
			ControlService(service, SERVICE_CONTROL_STOP, &status);
            //DeleteService(service);
            CloseServiceHandle(service);
            service = NULL;
            SetLastError(err);
        }
		else
		{
			PRINT_DBG(" WinDivertDriverInstall started service retries = %d\n", retries);

		}
    }
	else
	{
		PRINT_DBG(" WinDivertDriverInstall failed to find service\n");
	}

    err = GetLastError();
    if (manager != NULL)
    {
        CloseServiceHandle(manager);
    }
    SetLastError(err);
    
    return service;
}

/*
 * Perform a DeviceIoControl.
 */
static BOOL WinDivertIoControl(HANDLE handle, DWORD code, UINT8 arg8,
    UINT64 arg, PVOID buf, UINT len, UINT *iolen)
{
    OVERLAPPED overlapped;
    DWORD iolen0;
    HANDLE event;

    event = (HANDLE)TlsGetValue(windivert_tls_idx);
    if (event == (HANDLE)NULL)
    {
        event = CreateEvent(NULL, FALSE, FALSE, NULL);
        if (event == NULL)
        {
            return FALSE;
        }
        TlsSetValue(windivert_tls_idx, (LPVOID)event);
    }

    memset(&overlapped, 0, sizeof(overlapped));
    overlapped.hEvent = event;
    if (!WinDivertIoControlEx(handle, code, arg8, arg, buf, len, iolen,
            &overlapped))
    {
        if (GetLastError() != ERROR_IO_PENDING ||
            !GetOverlappedResult(handle, &overlapped, &iolen0, TRUE))
        {
            return FALSE;
        }
        if (iolen != NULL)
        {
            *iolen = (UINT)iolen0;
        }
    }
    return TRUE;
}

/*
 * Perform an (overlapped) DeviceIoControl.
 */
static BOOL WinDivertIoControlEx(HANDLE handle, DWORD code, UINT8 arg8,
    UINT64 arg, PVOID buf, UINT len, UINT *iolen, LPOVERLAPPED overlapped)
{
    struct windivert_ioctl_s ioctl;
    BOOL result;
    DWORD iolen0;

    ioctl.version = WINDIVERT_IOCTL_VERSION;
    ioctl.magic   = WINDIVERT_IOCTL_MAGIC;
    ioctl.arg8    = arg8;
    ioctl.arg     = arg;
    result = DeviceIoControl(handle, code, &ioctl, sizeof(ioctl), buf,
        (DWORD)len, &iolen0, overlapped);
    if (result && iolen != NULL)
    {
        *iolen = (UINT)iolen0;
    }
    return result;
}

/*
 * Open a WinDivert handle.
 */
HANDLE WinDivertOpen(__in const char *filter, __in WINDIVERT_LAYER layer,
	__in INT16 priority, __in UINT64 flags)
{
    struct windivert_ioctl_filter_s object[WINDIVERT_FILTER_MAXLEN];
    UINT obj_len;
    ERROR comp_err;
    DWORD err;
    HANDLE handle;
    SC_HANDLE service;
    UINT32 priority32;

	PRINT_DBG(" WinDivertOpen \n");
    // Parameter checking.
    if (!WINDIVERT_FLAGS_VALID(flags) || layer > WINDIVERT_LAYER_MAX)
    {
		_ERROR("failed parameter checking, flags = 0x%llx\n", flags);
        SetLastError(ERROR_INVALID_PARAMETER);
        return INVALID_HANDLE_VALUE;
    }
    priority32 = WINDIVERT_PRIORITY(priority);
    if (priority32 < WINDIVERT_PRIORITY_MIN ||
        priority32 > WINDIVERT_PRIORITY_MAX)
    {
		_ERROR("failed priority check, priority32 = %d\n", priority32);
		SetLastError(ERROR_INVALID_PARAMETER);
        return INVALID_HANDLE_VALUE;
    }
	
	PRINT_DBG(" WinDivertOpen Compile the filter\n");
    // Compile the filter:
    comp_err = WinDivertCompileFilter(filter, layer, object, &obj_len);
    if (IS_ERROR(comp_err))
    {
		if (filter == NULL)
		{
			_ERROR("unable to compile, NULL filter\n");
		}
		else
		{
			_ERROR("unable to compile filter %s\n", filter);
		}
		SetLastError(ERROR_INVALID_PARAMETER);
        return INVALID_HANDLE_VALUE;
    }

#ifdef WINDIVERT_DEBUG
    WinDivertFilterDump(object, obj_len);
#endif

	PRINT_DBG(" WinDivertOpen Attempt to open the WinDivert device\n");
    // Attempt to open the WinDivert device:
    handle = CreateFile(L"\\\\.\\" WINDIVERT_DEVICE_NAME,
        GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OVERLAPPED, INVALID_HANDLE_VALUE);
    if (handle == INVALID_HANDLE_VALUE)
    {
        err = GetLastError();
        if (err != ERROR_FILE_NOT_FOUND && err != ERROR_PATH_NOT_FOUND)
        {
            return INVALID_HANDLE_VALUE;
        }

        // Open failed because the device isn't installed; install it now.
        SetLastError(0);
        service = WinDivertDriverInstall();
        if (service == NULL)
        {
            if (GetLastError() == 0)
            {
                SetLastError(ERROR_OPEN_FAILED);
            }
            return INVALID_HANDLE_VALUE;
        }
        handle = CreateFile(L"\\\\.\\" WINDIVERT_DEVICE_NAME,
            GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING,
            FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OVERLAPPED,
            INVALID_HANDLE_VALUE);

        // Schedule the service to be deleted (once all handles are closed).
        //DeleteService(service);
        CloseServiceHandle(service);

        if (handle == INVALID_HANDLE_VALUE)
        {
			_ERROR(" WinDivertOpen INVALID_HANDLE_VALUE\n");
            return INVALID_HANDLE_VALUE;
        }
    }

    // Set the layer:
    if (layer != WINDIVERT_LAYER_DEFAULT)
    {
        if (!WinDivertIoControl(handle, IOCTL_WINDIVERT_SET_LAYER, 0,
                (UINT64)layer, NULL, 0, NULL))
        {
 			_ERROR(" WinDivertOpen bad layer \n");
			CloseHandle(handle);
            return INVALID_HANDLE_VALUE;
        }
    }

    // Set the flags:
    if (flags != 0)
    {
        if (!WinDivertIoControl(handle, IOCTL_WINDIVERT_SET_FLAGS, 0,
                (UINT64)flags, NULL, 0, NULL))
        {
 			_ERROR(" WinDivertOpen can't set flags \n");
           CloseHandle(handle);
            return INVALID_HANDLE_VALUE;
        }
    }

    // Set the priority:
    if (priority32 != WINDIVERT_PRIORITY_DEFAULT)
    {
        if (!WinDivertIoControl(handle, IOCTL_WINDIVERT_SET_PRIORITY, 0,
                (UINT64)priority32, NULL, 0, NULL))
        {
 			_ERROR(" WinDivertOpen can't set priority \n");
            CloseHandle(handle);
            return INVALID_HANDLE_VALUE;
        }
    }

    // Start the filter:
    if (!WinDivertIoControl(handle, IOCTL_WINDIVERT_START_FILTER, 0, 0,
            object, obj_len*sizeof(struct windivert_ioctl_filter_s), NULL))
    {
  	_ERROR(" WinDivertOpen can't start filter \n");
       CloseHandle(handle);
        return INVALID_HANDLE_VALUE;
    }

    // Success!
    return handle;
}

/*
* Receive a metrics.
*/
BOOL WinDivertGetMetrics(__in HANDLE handle, __out PVOID pMetrics, __in UINT metricsLen)
{
	BOOL rtnVal;
	rtnVal = WinDivertIoControl(handle, IOCTL_WINDIVERT_GET_METRICS, 0,
		0, pMetrics, metricsLen, NULL);
	return rtnVal;
}

/*
* Enable filtering.
*/
DWORD WINAPI WinDivertEnable(LPVOID filter)
{
	INT16 priority = 404;       // Arbitrary.
#ifdef MAVEN_DEBUG
	if (dbgLogFile == NULL)
	{
		fopen_s(&dbgLogFile, "C:\\maven\\windivert.txt", "w");
	}
#endif
	PRINT_DBG("WinDivertEnable %s", (char *)filter);
	driverHandle = WinDivertOpen((char *)filter,
		WINDIVERT_LAYER_NETWORK, priority, 0);
	return 0;
}

/*
* Disable filtering.
*/
BOOL WinDivertDisable(HANDLE handle)
{
	BOOL rtnVal;
	PRINT_DBG("WinDivertDisable\n");
	rtnVal = WinDivertIoControl(handle, IOCTL_WINDIVERT_STOP_FILTER, 0,
		0, NULL, 0, NULL);
#ifdef MAVEN_DEBUG
	if (dbgLogFile != NULL)
	{
		fclose(dbgLogFile);
		dbgLogFile = NULL;
	}
#endif
	return rtnVal;
}

/*
 * Receive a WinDivert packet.
 */
BOOL WinDivertRecv(__in HANDLE handle, __out PVOID pPacket, __in UINT packetLen,
	__out_opt PWINDIVERT_ADDRESS addr, __out_opt UINT *readlen)
{
	BOOL rtnVal;
	//PRINT_DBG("Recv");
    rtnVal = WinDivertIoControl(handle, IOCTL_WINDIVERT_RECV, 0, (UINT64)addr,
        pPacket, packetLen, readlen);
	//PRINT_DBG("\n");
	return rtnVal;

}

/*
 * Receive a WinDivert packet.
 */
BOOL WinDivertRecvEx(__in HANDLE handle, __out PVOID pPacket, __in UINT packetLen,
	__in UINT64 flags, __out_opt PWINDIVERT_ADDRESS addr, __out_opt UINT *readlen,
	__inout_opt LPOVERLAPPED overlapped)
{
	BOOL retVal;
	//PRINT_DBG("RecvEx ");

	if (flags != 0)
    {
		PRINT_DBG("WinDivertRecvEx - ERROR_INVALID_PARAMETER \n");
		SetLastError(ERROR_INVALID_PARAMETER);
        return FALSE;
    }
    if (overlapped == NULL)
    {
		//PRINT_DBG("IOC ");
		retVal = WinDivertIoControl(handle, IOCTL_WINDIVERT_RECV, 0,
            (UINT64)addr, pPacket, packetLen, readlen);

    }
    else
    {
		//PRINT_DBG("IOCEX ");
		retVal = WinDivertIoControlEx(handle, IOCTL_WINDIVERT_RECV, 0,
            (UINT64)addr, pPacket, packetLen, readlen, overlapped);
    }

	//PRINT_DBG("\n");

	return retVal;
}

/*
 * Send a WinDivert packet.
 */
BOOL WinDivertSend(HANDLE handle, PVOID pPacket, UINT packetLen,
    PWINDIVERT_ADDRESS addr, UINT *writelen)
{
	BOOL retVal;
	//PRINT_DBG("Send");
	retVal = WinDivertIoControl(handle, IOCTL_WINDIVERT_SEND, 0, (UINT64)addr,
        pPacket, packetLen, writelen);

	//PRINT_DBG("\n");
	return retVal;
}

/*
 * Send a WinDivert packet.
 */
BOOL WinDivertSendEx(HANDLE handle, PVOID pPacket, UINT packetLen,
    UINT64 flags, PWINDIVERT_ADDRESS addr, UINT *writelen,
    LPOVERLAPPED overlapped)
{
	BOOL retVal;
	PRINT_DBG("SendEx");
	if (flags != 0)
    {
        SetLastError(ERROR_INVALID_PARAMETER);
		PRINT_DBG("\n");
		return FALSE;
    }
    if (overlapped == NULL)
    {
		PRINT_DBG("C ");
		retVal = WinDivertIoControl(handle, IOCTL_WINDIVERT_SEND, 0,
            (UINT64)addr, pPacket, packetLen, writelen);
    }
    else
    {
		PRINT_DBG("CEx ");
		retVal = WinDivertIoControlEx(handle, IOCTL_WINDIVERT_SEND, 0,
            (UINT64)addr, pPacket, packetLen, writelen, overlapped);
    }
	PRINT_DBG("\n");
	return retVal;
}

/*
 * Close a WinDivert handle.
 */
BOOL WinDivertClose(HANDLE handle)
{
    return CloseHandle(handle);
}

/*
 * Set a WinDivert parameter.
 */
BOOL WinDivertSetParam(HANDLE handle, WINDIVERT_PARAM param,
    UINT64 value)
{
    switch ((int)param)
    {
        case WINDIVERT_PARAM_QUEUE_LEN:
            if (value < WINDIVERT_PARAM_QUEUE_LEN_MIN ||
                value > WINDIVERT_PARAM_QUEUE_LEN_MAX)
            {
                SetLastError(ERROR_INVALID_PARAMETER);
                return FALSE;
            }
            break;
        case WINDIVERT_PARAM_QUEUE_TIME:
            if (value < WINDIVERT_PARAM_QUEUE_TIME_MIN ||
                value > WINDIVERT_PARAM_QUEUE_TIME_MAX)
            {
                SetLastError(ERROR_INVALID_PARAMETER);
                return FALSE;
            }
            break;
        case WINDIVERT_PARAM_QUEUE_SIZE:
            if (value < WINDIVERT_PARAM_QUEUE_SIZE_MIN ||
                value > WINDIVERT_PARAM_QUEUE_SIZE_MAX)
            {
                SetLastError(ERROR_INVALID_PARAMETER);
                return FALSE;
            }
            break;
        default:
            SetLastError(ERROR_INVALID_PARAMETER);
            return FALSE;
    }
    return WinDivertIoControl(handle, IOCTL_WINDIVERT_SET_PARAM, (UINT8)param,
        value, NULL, 0, NULL);
}

/*
 * Get a WinDivert parameter.
 */
BOOL WinDivertGetParam(HANDLE handle, WINDIVERT_PARAM param,
    UINT64 *pValue)
{
	BOOL retVal;
	PRINT_DBG("GetParam ");

	switch ((int)param)
    {
        case WINDIVERT_PARAM_QUEUE_LEN: case WINDIVERT_PARAM_QUEUE_TIME:
            break;
        default:
            SetLastError(ERROR_INVALID_PARAMETER);
            return FALSE;
    }
	retVal = WinDivertIoControl(handle, IOCTL_WINDIVERT_GET_PARAM, (UINT8)param,
        0, pValue, sizeof(UINT64), NULL);
	PRINT_DBG("\n");
	return retVal;
}

/*****************************************************************************/
/* REPLACEMENTS                                                              */
/*****************************************************************************/

static BOOLEAN WinDivertStrLen(const wchar_t *s, size_t maxlen,
    size_t *lenptr)
{
    size_t i;
    for (i = 0; s[i]; i++)
    {
        if (i > maxlen)
        {
            return FALSE;
        }
    }
    *lenptr = i;
    return TRUE;
}

static BOOLEAN WinDivertStrCpy(wchar_t *dst, size_t dstlen, const wchar_t *src)
{
    size_t i;
    for (i = 0; src[i]; i++)
    {
        if (i > dstlen)
        {
            return FALSE;
        }
        dst[i] = src[i];
    }
    if (i > dstlen)
    {
        return FALSE;
    }
    dst[i] = src[i];
    return TRUE;
}

static BOOLEAN WinDivertAToI(const char *str, char **endptr, UINT32 *intptr)
{
    size_t i = 0;
    UINT32 num = 0, num0;
    if (str[i] == '\0')
    {
        return FALSE;
    }
    for (; str[i] && isdigit(str[i]); i++)
    {
        num0 = num;
        num *= 10;
        num += (UINT32)(str[i] - '0');
        if (num0 > num)
        {
            return FALSE;
        }
    }
    if (endptr != NULL)
    {
        *endptr = (char *)str + i;
    }
    *intptr = num;
    return TRUE;
}

static BOOLEAN WinDivertAToX(const char *str, char **endptr, UINT32 *intptr)
{
    size_t i = 0;
    UINT32 num = 0, num0;
    if (str[i] == '\0')
    {
        return FALSE;
    }
    if (str[i] == '0' && str[i+1] == 'x')
    {
        i += 2;
    }
    for (; str[i] && isxdigit(str[i]); i++)
    {
        num0 = num;
        num *= 16;
        if (isdigit(str[i]))
        {
            num += (UINT32)(str[i] - '0');
        }
        else
        {
            num += (UINT32)(tolower(str[i]) - 'a') + 0x0A;
        }
        if (num0 > num)
        {
            return FALSE;
        }
    }
    if (endptr != NULL)
    {
        *endptr = (char *)str + i;
    }
    *intptr = num;
    return TRUE;
}

/***************************************************************************/
/* DEBUGGING                                                               */
/***************************************************************************/

#ifdef WINDIVERT_DEBUG
/*
 * Print a filter (debugging).
 */
static void WinDivertFilterDump(windivert_ioctl_filter_t filter, UINT16 len)
{
    UINT16 i;

    for (i = 0; i < len; i++)
    {
        printf("label_%u:\n\tif (", i);
        switch (filter[i].field)
        {
            case WINDIVERT_FILTER_FIELD_ZERO:
                printf("zero ");
                break;
            case WINDIVERT_FILTER_FIELD_INBOUND:
                printf("inbound ");
                break;
            case WINDIVERT_FILTER_FIELD_OUTBOUND:
                printf("outbound ");
                break;
            case WINDIVERT_FILTER_FIELD_IFIDX:
                printf("ifIdx ");
                break;
            case WINDIVERT_FILTER_FIELD_SUBIFIDX:
                printf("subIfIdx ");
                break;
            case WINDIVERT_FILTER_FIELD_IP:
                printf("ip ");
                break;
            case WINDIVERT_FILTER_FIELD_IPV6:
                printf("ipv6 ");
                break;
            case WINDIVERT_FILTER_FIELD_ICMP:
                printf("icmp ");
                break;
            case WINDIVERT_FILTER_FIELD_ICMPV6:
                printf("icmpv6 ");
                break;
            case WINDIVERT_FILTER_FIELD_TCP:
                printf("tcp ");
                break;
            case WINDIVERT_FILTER_FIELD_UDP:
                printf("udp ");
                break;
            case WINDIVERT_FILTER_FIELD_IP_HDRLENGTH:
                printf("ip.HdrLength ");
                break;
            case WINDIVERT_FILTER_FIELD_IP_TOS:
                printf("ip.TOS ");
                break;
            case WINDIVERT_FILTER_FIELD_IP_LENGTH:
                printf("ip.Length ");
                break;
            case WINDIVERT_FILTER_FIELD_IP_ID:
                printf("ip.Id ");
                break;
            case WINDIVERT_FILTER_FIELD_IP_DF:
                printf("ip.DF ");
                break;
            case WINDIVERT_FILTER_FIELD_IP_MF:
                printf("ip.MF ");
                break;
            case WINDIVERT_FILTER_FIELD_IP_FRAGOFF:
                printf("ip.FragOff ");
                break;
            case WINDIVERT_FILTER_FIELD_IP_TTL:
                printf("ip.TTL ");
                break;
            case WINDIVERT_FILTER_FIELD_IP_PROTOCOL:
                printf("ip.Protocol ");
                break;
            case WINDIVERT_FILTER_FIELD_IP_CHECKSUM:
                printf("ip.Checksum ");
                break;
            case WINDIVERT_FILTER_FIELD_IP_SRCADDR:
                printf("ip.SrcAddr ");
                break;
            case WINDIVERT_FILTER_FIELD_IP_DSTADDR:
                printf("ip.DstAddr ");
                break;
            case WINDIVERT_FILTER_FIELD_IPV6_TRAFFICCLASS:
                printf("ipv6.TrafficClass ");
                break;
            case WINDIVERT_FILTER_FIELD_IPV6_FLOWLABEL:
                printf("ipv6.FlowLabel ");
                break;
            case WINDIVERT_FILTER_FIELD_IPV6_LENGTH:
                printf("ipv6.Length ");
                break;
            case WINDIVERT_FILTER_FIELD_IPV6_NEXTHDR:
                printf("ipv6.NextHdr ");
                break;
            case WINDIVERT_FILTER_FIELD_IPV6_HOPLIMIT:
                printf("ipv6.HopLimit ");
                break;
            case WINDIVERT_FILTER_FIELD_IPV6_SRCADDR:
                printf("ipv6.SrcAddr ");
                break;
            case WINDIVERT_FILTER_FIELD_IPV6_DSTADDR:
                printf("ipv6.DstAddr ");
                break;
            case WINDIVERT_FILTER_FIELD_ICMP_TYPE:
                printf("icmp.Type ");
                break;
            case WINDIVERT_FILTER_FIELD_ICMP_CODE:
                printf("icmp.Code ");
                break;
            case WINDIVERT_FILTER_FIELD_ICMP_CHECKSUM:
                printf("icmp.Checksum ");
                break;
            case WINDIVERT_FILTER_FIELD_ICMP_BODY:
                printf("icmp.Body ");
                break;
            case WINDIVERT_FILTER_FIELD_ICMPV6_TYPE:
                printf("icmpv6.Type ");
                break;
            case WINDIVERT_FILTER_FIELD_ICMPV6_CODE:
                printf("icmpv6.Code ");
                break;
            case WINDIVERT_FILTER_FIELD_ICMPV6_CHECKSUM:
                printf("icmpv6.Checksum ");
                break;
            case WINDIVERT_FILTER_FIELD_ICMPV6_BODY:
                printf("icmpv6.Body ");
                break;
            case WINDIVERT_FILTER_FIELD_TCP_SRCPORT:
                printf("tcp.SrcPort ");
                break;
            case WINDIVERT_FILTER_FIELD_TCP_DSTPORT:
                printf("tcp.DstPort ");
                break;
            case WINDIVERT_FILTER_FIELD_TCP_SEQNUM:
                printf("tcp.SeqNum ");
                break;
            case WINDIVERT_FILTER_FIELD_TCP_ACKNUM:
                printf("tcp.AckNum ");
                break;
            case WINDIVERT_FILTER_FIELD_TCP_HDRLENGTH:
                printf("tcp.HdrLength ");
                break;
            case WINDIVERT_FILTER_FIELD_TCP_URG:
                printf("tcp.Urg ");
                break;
            case WINDIVERT_FILTER_FIELD_TCP_ACK:
                printf("tcp.Ack ");
                break;
            case WINDIVERT_FILTER_FIELD_TCP_PSH:
                printf("tcp.Psh ");
                break;
            case WINDIVERT_FILTER_FIELD_TCP_RST:
                printf("tcp.Rst ");
                break;
            case WINDIVERT_FILTER_FIELD_TCP_SYN:
                printf("tcp.Syn ");
                break;
            case WINDIVERT_FILTER_FIELD_TCP_FIN:
                printf("tcp.Fin ");
                break;
            case WINDIVERT_FILTER_FIELD_TCP_WINDOW:
                printf("tcp.Window ");
                break;
            case WINDIVERT_FILTER_FIELD_TCP_CHECKSUM:
                printf("tcp.Checksum ");
                break;
            case WINDIVERT_FILTER_FIELD_TCP_URGPTR:
                printf("tcp.UrgPtr ");
                break;
            case WINDIVERT_FILTER_FIELD_TCP_PAYLOADLENGTH:
                printf("tcp.PayloadLength " );
                break;
            case WINDIVERT_FILTER_FIELD_UDP_SRCPORT:
                printf("udp.SrcPort ");
                break;
            case WINDIVERT_FILTER_FIELD_UDP_DSTPORT:
                printf("udp.DstPort ");
                break;
            case WINDIVERT_FILTER_FIELD_UDP_LENGTH:
                printf("udp.Length ");
                break;
            case WINDIVERT_FILTER_FIELD_UDP_CHECKSUM:
                printf("udp.Checksum ");
                break;
            case WINDIVERT_FILTER_FIELD_UDP_PAYLOADLENGTH:
                printf("udp.PayloadLength ");
                break;
            default:
                printf("unknown.Field ");       
                break;
        }
        switch (filter[i].test)
        {
            case WINDIVERT_FILTER_TEST_EQ:
                printf("== ");
                break;
            case WINDIVERT_FILTER_TEST_NEQ:
                printf("!= ");
                break;
            case WINDIVERT_FILTER_TEST_LT:
                printf("< ");
                break;
            case WINDIVERT_FILTER_TEST_LEQ:
                printf("<= ");
                break;
            case WINDIVERT_FILTER_TEST_GT:
                printf("> ");
                break;
            case WINDIVERT_FILTER_TEST_GEQ:
                printf(">= ");
                break;
            default:
                printf("?? ");
                break;
        }
        printf("%u)\n", filter[i].arg[0]);
        switch (filter[i].success)
        {
            case WINDIVERT_FILTER_RESULT_ACCEPT:
                printf("\t\treturn ACCEPT;\n");
                break;
            case WINDIVERT_FILTER_RESULT_REJECT:
                printf("\t\treturn REJECT;\n");
                break;
            default:
                printf("\t\tgoto label_%u;\n", filter[i].success);
                break;
        }
        printf("\telse\n");
        switch (filter[i].failure)
        {
            case WINDIVERT_FILTER_RESULT_ACCEPT:
                printf("\t\treturn ACCEPT;\n");
                break;
            case WINDIVERT_FILTER_RESULT_REJECT:
                printf("\t\treturn REJECT;\n");
                break;
            default:
                printf("\t\tgoto label_%u;\n", filter[i].failure);
                break;
        }
    }
}

#endif      /* WINDIVERT_DEBUG */

