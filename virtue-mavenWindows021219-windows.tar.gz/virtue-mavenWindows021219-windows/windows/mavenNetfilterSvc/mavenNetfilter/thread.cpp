/* Copyright(c) 2019 Siege Technologies, 1105 Floyd Avenue Rome, NY 13440

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files(the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions :

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/#include "stdafx.h"

#define LINE_SIZE PAYLOAD_MSG_SZ

#define TEST_STRING pChar=&pInstring[i]; /* for debug */
#define END_OF_STRING ((pInstring[i] == '\0') || (pInstring[i] == '\n') || (pInstring[i] == EOF))
#define FIND_WHITESPACE while (!isspace(pInstring[i]) && !END_OF_STRING) {i++; TEST_STRING }
#define PASS_WHITESPACE while (isspace(pInstring[i]) && !END_OF_STRING) {i++; TEST_STRING }
#define PASS_TO_EOL while (!END_OF_STRING && (pInstring[i] != '\r')){i++;TEST_STRING}
#define PASS_TO_NEXT_LINE while ((pInstring[i] == '\n') || (pInstring[i] == '\r')){i++;TEST_STRING}
#define FIND_COMMA	while(!END_OF_STRING && (pInstring[i]!= ',')){i++;TEST_STRING}
#define FIND_SPACE	while((pInstring[i] != ' ') && !END_OF_STRING && (pInstring[i]!= ',')){i++;TEST_STRING}
#define FIND_EQUALS	while(!END_OF_STRING && (pInstring[i]!= '=')){i++;TEST_STRING}
#define EXIT_IF_DONE if END_OF_STRING goto configExit;
#define IS_A_NUM(c) ((c >= '0') && (c <= '9') || ( c == '.') )
#define FIND_SLASH while((pInstring[i] != '/') && !END_OF_STRING){i++;TEST_STRING}

#ifdef MAVEN_DEBUG
#if (defined HIDDEN_CONSOLE) || (defined MAVEN_SERVICE)
extern "C" FILE  *dbgLogFile;
#define PRINT_DBG(...) {fprintf(dbgLogFile, __VA_ARGS__); fflush(dbgLogFile);}
#define WPRINT_DBG(...) 
#else
#define PRINT_DBG(...) printf(__VA_ARGS__)
#define WPRINT_DBG(...) wprintf(__VA_ARGS__)
#endif
#else /* HIDDEN_CONSOLE */
#define PRINT_DBG(...)
#define WPRINT_DBG(...)
#endif

static char module_name[] = { "thread.cpp" };

static int nextFilterEntry = 0;
int eventThreshold = 1;		/* max blocked packets per heartbeat */

static const char *serverString[SERVER_NET_NUM_CMDS] = {
	SERVER_NET_CMD_FILTER, SERVER_NET_CMD_IDLE, 
	SERVER_NET_CMD_EXIT, SERVER_NET_CMD_STATUS
};

static const char *metricsString[] = {
	"icmpIn",
	"tcpIn",
	"udpIn",
	"icmpOut",
	"tcpOut",
	"udpOut"
};

typedef enum _METRICS_ITEM {
	METRICS_ICMP_IN,
	METRICS_TCP_IN,
	METRICS_UDP_IN,
	METRICS_ICMP_OUT,
	METRICS_TCP_OUT,
	METRICS_UDP_OUT
}METRICS_ITEM;

extern int processConfigString(char *pInstring, UINT *pHeartbeat, NETFILTER_LOG_MODE *logMode);
extern NETFILTER_LOG_MODE logMode;
extern NETFILTER_STATE netState;

#define NUM_METRICS 6
double metricsLastComputed = 0.0;
static UINT64 lastMetric[NUM_METRICS] = { 0 };
static UINT64 metricLimits[NUM_METRICS] = { 0 };

static char nullArg[] = "\0";
static const char *netStateString[2] = { "Idle", "Filter" };

NETFILTER_STATE netState = NETFILTER_FILTER;

char defaultConfig[] =
// "outbound && "           /* Outbound traffic only */
"icmp || "					/* ICMP */
"udp || "					/* UDP */
"!loopback && "             /* No loopback traffic */
"ip && "                    /* IPv4 */
"!tcp.DstPort == 65000 && " /* not maven port */
"!tcp.DstPort == 5170 && "  /* not fluentd port */
"!tcp.DstPort == 3389 && "  /* not RDP port */
"!tcp.DstPort == 4022 && "  /* not remote debugger port */
							// "tcp.DstPort == 80 && "  /* HTTP (port 80) only */
	"tcp.PayloadLength > 0"     /* TCP data packets only */
	"icmp || "					/* ICMP */
	"udp";						/* UDP */

/***************************************************************************
* Name:recvMsg
*
* Routine Description: This function receives a message from a socket and 
*	collects message fragments until the entire message is received.
*
* Returns: number of bytes received or zero if error
*
**************************************************************************/
int recvMsg(
	SOCKET s,	/* socket */
	char *buf,	/* pointer to receive buffer */
	int bufLen	/* size of receive buffer */
)
{
	int bytesReceived = 0;
	int index = 0;

	do {
		/* normally, the entire message is received at once, but
		 * large messages can be fragmented */
		bytesReceived = recv(s, &buf[index], bufLen - index, 0);
		if (bytesReceived < 0)
		{
			_ERROR(" recv error %d\n", WSAGetLastError());
			return 0;
		}
		index += bytesReceived;
		if ((bufLen - index) <= 0)
		{
			_ERROR("recv error - buffer overflow\n");
			return 0;
		}
	} while (buf[index - 1] != '\0');	/* defragment until string terminator found */
	return index;
}

/***************************************************************************
* Name: scanForDecimal
*
* Routine Description: This function substitutes for swscanf which doesn't
* link, sounds like a bug to me.
*
* Works only for unsigned 32-bit numbers
*
* Returns:  returns number of characters parsed or zero if error
*
**************************************************************************/
int scanForDecimal(
	CHAR *pString, /* input string */
	UINT *pValue /* output value */
)
{
	int numChars = 0;	/* number of characters advanced in string or zero if error */

	*pValue = 0;

	/* search for delimeter or digit */
	while ((*pString != 0) && (*pString >= '0') && (*pString <= '9'))
	{
		*pValue = *pValue * 10 + (*pString - L'0');
		pString++;	/* next charater */
		numChars++;
	}
	return numChars;

}

/***************************************************************************
* Name: processConfigString
*
* Routine Description: This function parses the passed configuration string
*	and initializes the filter configuration settings.  The passed string
*	has the following format:
*		!heartbeat=<heartbeat>, log=<logMode>;<comment>
*	where
*		<heartbeat> is in seconds (decimal)
*		<logMode> is one of all, none, events
*	whitespaces are ignored between keywords.
*	only the first character of tokens is checked, case insensitive
*	the comment is optional.  If present, it will be preceeded by a semicolon
*
* Returns:  Number of characters parsed.
*
**************************************************************************/
int processConfigString(
	char *pInstring,				/* string to parse */
	UINT *pHeartbeat,				/* output - heartbeat rate */
	NETFILTER_LOG_MODE *logMode
)
{
	int i = 0;
	int j, k;
	size_t len;
	BOOL done = FALSE;
	char *pChar;

	while (!done)
	{
		PASS_WHITESPACE;
		/* we should have a token here, either 'm' or 'h' */
		switch (pInstring[i])
		{
		case 'h':
		case 'H':
			FIND_EQUALS;
			EXIT_IF_DONE;
			i++; /* advance past equals */
			EXIT_IF_DONE;
			PASS_WHITESPACE;
			EXIT_IF_DONE;
			/* we should now be pointing to the heartbeat string */
			j = scanForDecimal(&pInstring[i], pHeartbeat);
			if (j == 0)
			{
				*pHeartbeat = HEARTBEAT_DELAY;
			}
			else
			{
				*pHeartbeat *= 1000; /* sec to ms */
			}
			i += j;
			PRINT_DBG("processConfigString heartbeat = %d\n", *pHeartbeat);
			i++; /* advance past comma */
			EXIT_IF_DONE;
			break;
		case 'm':
		case 'M':
			FIND_SPACE;
			EXIT_IF_DONE;
			PASS_WHITESPACE;
			EXIT_IF_DONE;
			/* should now be pointing at metrics limit string */
			for (k = 0; k < NUM_METRICS; k++)
			{
				len = strlen(metricsString[k]);
				if (strncmp(&pInstring[i], metricsString[k], len) == 0)
				{
					UINT metric;
					/* matched one of the metrics limits */
					FIND_EQUALS;
					EXIT_IF_DONE;
					i++; /* advance past equals */
					EXIT_IF_DONE;
					PASS_WHITESPACE;
					EXIT_IF_DONE;
					/* we should now be pointing to the limit string */
					i += scanForDecimal(&pInstring[i], &metric);
					metricLimits[k] = metric;
					PRINT_DBG("processConfigString metricLimits[%d] = %d\n", k, metric);
					if (pInstring[i] == ',')
						i++; /* advance past comma */
					EXIT_IF_DONE;
					break;
				}
			}
			if (k == NUM_METRICS)
			{
				done = TRUE;
			}
			break;
		case 'l':
		case 'L':
			FIND_EQUALS;
			EXIT_IF_DONE;
			i++; /* advance past equals */
			EXIT_IF_DONE;
			PASS_WHITESPACE;
			EXIT_IF_DONE;
			/* we should now be pointing to the log mode */
			switch (pInstring[i])
			{
			case 'a':
			case 'A':
				*logMode = NETFILTER_LOG_ALL;
				PRINT_DBG("processConfigString NETFILTER_LOG_ALL \n");
				break;
			case 'n':
			case 'N':
				*logMode = NETFILTER_LOG_NONE;
				PRINT_DBG("processConfigString NETFILTER_LOG_NONE \n");
				break;
			case 'e':
			case 'E':
				*logMode = NETFILTER_LOG_EVENTS;
				PRINT_DBG("processConfigString NETFILTER_LOG_EVENTS \n");
				break;
			default:
				break;
			}
			FIND_COMMA;
			EXIT_IF_DONE;
			i++; /* advance past comma */
			EXIT_IF_DONE;
			break;
		default:
		case ';':	/* comment */
			done = TRUE;
		}
	}
configExit:
	PASS_TO_EOL;
	PASS_TO_NEXT_LINE;
	return i;
}

/***************************************************************************
* Name: processAccessString
*
* Routine Description: This function processes a string entry from the
*	filter configuration file.  It constructs a filterList used by
*	the application for blacklisting and whitelisting.
*
* Returns:  N/A
*
**************************************************************************/
void processAccessString(char *pInstring, BOOL block)
{
	FILTER_LIST_ENTRY *pFilterList;
	char *pChar;
	int dLen = 0;
	int uLen = 0;
	int i = 0;

	if (nextFilterEntry == (FILTER_LIST_SZ - 1))
	{
		_ERROR("processAccessString no room\n");
		return;	/* full */
	}

	/* get next empty entry */
	pFilterList = &filterList[nextFilterEntry];

	/* save action */
	pFilterList->block = block;

	/* if it's an IP address */
	if (IS_A_NUM(*pInstring))
	{
		char * mask = NULL;
		pFilterList->entryType = IP_ITEM;

		/* find end of address */
		while (IS_A_NUM(pInstring[i]))
		{
			i++;
		}

		/* get pointer to IP mask (optional) */
		if (pInstring[i] == '/') 
		{
			mask = &pInstring[i + 1];
		}
		pInstring[i] = '\0'; /* null terminate IP address */

		/* convert the string to an IP address */
		if (inet_pton(AF_INET, pInstring, &pFilterList->entry.ipEntry.address))
		{
			PRINT_DBG("processAccessString converts address 0x%x\n", pFilterList->entry.ipEntry.address);
		}
		else
		{
			pFilterList->entryType = UNKNOWN_ITEM;	/* error, can't convet */
			PRINT_DBG("processAccessString unable to convert address %s\n", pInstring);
			goto configExit;
		}
		/* convert the netmask to an IP address */
		if (mask != NULL) 
		{
			i++; /* advance past slash */
			while (IS_A_NUM(pInstring[i]))
			{
				i++;	/* find end of mask */
			}
			pInstring[i] = '\0'; /* null terminate mask */
			if (inet_pton(AF_INET, mask, &pFilterList->entry.ipEntry.mask))
			{
				PRINT_DBG("processAccessString converts mask 0x%x\n", pFilterList->entry.ipEntry.mask);
			}
			else
			{
				PRINT_DBG("processAccessString unable to convert mask %s\n", mask);
			}
		}
		else
		{
			/* no netmask */
			pFilterList->entry.ipEntry.mask = 0xffffffff;
		}

	}
	
	else /* it's a URL */
	{
		char *pDomain = 0;
		char *pUri = 0;

		pFilterList->entryType = URL_ITEM;

		PASS_WHITESPACE; /* advance past leading whitespace */
		if (END_OF_STRING)
		{
			PRINT_DBG("processAccessString unable to convert URL %s\n", pInstring);
			goto configExit;
		}
		if (pInstring[i] != '-' && !isalnum(pInstring[i]))
		{
			i++;
			PASS_WHITESPACE; /* advance past leading whitespace */
			if (END_OF_STRING)
			{
				PRINT_DBG("processAccessString unable to convert URL %s\n", pInstring);
				goto configExit;
			}
		}

		/* find and determine length of domain and uri */
		pDomain = &pInstring[i];
		while ( ( (isalnum(pInstring[i])) || (pInstring[i] == '-') || (pInstring[i] == '.'))
			&& (i < (MAXURL - 1)))
		{
			dLen++;
			i++;
		}

		if (pInstring[i] == '/')
		{
			pUri = &pInstring[++i];

			while (!isspace(pInstring[i]) && !END_OF_STRING && (uLen < (MAXURL - 1)))
			{
				uLen++;
				i++;
			}
		}

		/* allocate domain and uri */
		if (dLen == 0)
		{
			pFilterList->entry.urlEntry.domain = NULL;
		}
		else
		{
			pDomain[dLen] = '\0';	/* terminate */
			pFilterList->entry.urlEntry.domain = (char *)malloc((dLen + 1) * sizeof(char));
			if (pFilterList->entry.urlEntry.domain == NULL)
			{
				goto configExit;
			}
			strcpy_s(pFilterList->entry.urlEntry.domain, dLen + 1, pDomain);
		}

		if (uLen == 0)
		{
			pFilterList->entry.urlEntry.uri = NULL;
		}
		else
		{
			pUri[uLen] = '\0';	/* terminate */
			pFilterList->entry.urlEntry.uri = (char *)malloc((uLen + 1) * sizeof(char));
			if (pFilterList->entry.urlEntry.uri == NULL)
			{
				goto configExit;
			}
			strcpy_s(pFilterList->entry.urlEntry.uri, uLen + 1, pUri);
		}

		PRINT_DBG("ADD %s/%s\n", pDomain, pUri);
	}

	nextFilterEntry++;
	return;

configExit:
	if (pFilterList->entryType == URL_ITEM)
	{
		if (pFilterList->entry.urlEntry.domain)
		{
			free(pFilterList->entry.urlEntry.domain);
		}
		if (pFilterList->entry.urlEntry.uri)
		{
			free(pFilterList->entry.urlEntry.uri);
		}
	}
	memset(pFilterList, 0, sizeof(FILTER_LIST_ENTRY));

}

/***************************************************************************
* Name: initializeConfigFile
*
* Routine Description: This function initializes the whitelist/blacklist
*	configuration file.
*
* Returns: N/A
*
**************************************************************************/
void initializeConfigFile(void)
{
	FILTER_LIST_ENTRY *pFilterList;
	int i;
	nextFilterEntry = 0;

	for (i = 0; i < FILTER_LIST_SZ; i++)
	{
		pFilterList = &filterList[i];
		/* url entries have allocated entries */
		if (pFilterList->entryType == URL_ITEM)
		{
			/* free any buffers */
			if (pFilterList->entry.urlEntry.domain)
				free(pFilterList->entry.urlEntry.domain);
			if (pFilterList->entry.urlEntry.uri)
				free(pFilterList->entry.urlEntry.uri);
		}

		memset(pFilterList, 0, sizeof(FILTER_LIST_ENTRY));
	}

}

/***************************************************************************
* Name: processConfigFile
*
* Routine Description: This function reads entries from the filter
*	configuration file.  It uses the first character of each line to 
*	identify entry type, and parses to the appropriate function based on
*	type.
*
* Returns: N/A
*
**************************************************************************/
void processConfigFile(FILE *configFile)
{
	char readBuf[PAYLOAD_MSG_SZ];

	initializeConfigFile();	/* initialize old list */

	while (fgets(readBuf, PAYLOAD_MSG_SZ, configFile) != NULL)
	{
		int i = 0;
		char *pChar;
		char * pInstring = readBuf;
		/* advance past line type field */
		FIND_WHITESPACE;
		PASS_WHITESPACE;
		switch (readBuf[0])
		{
		case 's':
		case 'S':
			strcpy_s(windivertConfigString, MAXCONFIG, &pInstring[i]);
			break;
		case 'F': /* filter configuration line */
		case 'f':
			/* parse netfilter configuration settings */
			processConfigString(&pInstring[i], &heartbeat, &logMode);
			break;
		case 'B': /* block access line */
		case 'b':
		case 'A': /* allow access line */
		case 'a':
			/* parse whitelist or blacklist entry */
			processAccessString(&pInstring[i], 
				((readBuf[0] == 'B') || (readBuf[0] == 'b')));
			break;
		default:
			break;
		}
	}
}

/***************************************************************************
* Name: sendStatus
*
* Routine Description: This function sends out filter status.
*
* Returns: N/A
*
**************************************************************************/
void sendStatus(
	double timePassed,
	char *pString
)
{
	char outBuf[LINE_SIZE];
	int iResult;
	HRESULT hResult = S_OK;

	/* log metrics to file */
	sprintf_s(outBuf, LINE_SIZE,  NETFILTER_ID_STRING " Status Mode = %s, Time=%8.2f, "
		"icmpCountInbound %lld, icmpv6CountInbound %lld, "
		"tcpCountInbound %lld, udpCountInbound %lld\n"
		"     icmpCountOutbound %lld, icmpv6CountOutbound %lld, "
		"tcpCountOutbound %lld, udpCountOutbound %lld eventCount=%d %s\n",
		netStateString[netState], timePassed,
		metrics.icmpCountInbound, metrics.icmpv6CountInbound,
		metrics.tcpCountInbound, metrics.udpCountInbound,
		metrics.icmpCountOutbound, metrics.icmpv6CountOutbound,
		metrics.tcpCountOutbound, metrics.udpCountOutbound,
		eventCount, pString);
	/* Send a metrics message */
	PRINT_DBG("statusWorkerThread sends message %s", outBuf);
	iResult = send(ConnectSocket, outBuf, (int)strlen(outBuf) + 1, 0);
	if (iResult == SOCKET_ERROR) {
		hResult = NS_E_INTERNAL_SERVER_ERROR;
		_ERROR("send failed with error: %d\n", WSAGetLastError());
	}
}


/***************************************************************************
* Name: parseServerCommand
*
* Routine Description: This function searches the first word of the
*	passed command line for a match with one of the predefined filter
*	commands.
*
* Returns: Enumerated command ID
*
**************************************************************************/
MAVEN_SERVER_NET_COMMAND parseServerCommand(
	char *serverRecvbuf,
	char **argString)
{
	int i;
	size_t cmdLen;
	*argString = nullArg;
	PRINT_DBG("mavenNetFilter - parsing %s\n", serverRecvbuf);
	for (i = 0; i < SERVER_NET_NUM_CMDS; i++)
	{
		cmdLen = strlen(serverString[i]);
		PRINT_DBG("    comparing (%s) to %s size=%zd\n", serverString[i],
			serverRecvbuf, cmdLen);
		if (strncmp(serverString[i], serverRecvbuf, cmdLen) == 0) {
			/* argument uses space as field seperator */
			if (serverRecvbuf[cmdLen] == ' ') {
				*argString = serverRecvbuf + cmdLen + 1;
			}
			break; /* found valid command */
		}
	}
	return (MAVEN_SERVER_NET_COMMAND)i;
}

/***************************************************************************
* Name: clientWorkerThread
*
* Routine Description: This function waits for commands.  When received,
*	it parses each command and obtains updated status from the filter.
*
* Returns: Filter status
*
**************************************************************************/
DWORD WINAPI clientWorkerThread(LPVOID lpParam)
{
	char outBuf[LINE_SIZE];
	LARGE_INTEGER base;
	LARGE_INTEGER freq;
	int iResult;
	int wsaError = 0;
	MAVEN_SERVER_NET_COMMAND serverCommand;
	char serverRecvbuf[SERVER_CMD_SIZE];
	char serverResponsebuf[SERVER_RESPONSE_SIZE];
	char *pServerResponsebuf;
	char *argString;
	char OKstring[] = "    ";
	char ErrString[] = "****";

	// Set up timing:
	QueryPerformanceFrequency(&freq);
	QueryPerformanceCounter(&base);
	pServerResponsebuf = (char *)((size_t)serverResponsebuf); /* start forming output string */

	PRINT_DBG("clientWorkerThread - receive\n");
	while (1) 
	{
		HRESULT hResult = S_OK;
		double timePassed;
		LARGE_INTEGER timestamp;
		char *pString = OKstring;
		int recvIndex = 0;
		if (!recvMsg(ConnectSocket, serverRecvbuf, SERVER_CMD_SIZE))
		{
			_ERROR("clientWorkerThread - receive error\n");
			return 0;
		}

		/* we received a message from the server */
		serverCommand = parseServerCommand(serverRecvbuf, &argString);
		PRINT_DBG("netfilter clientWorkerThread received %s, serverCommand=%d\n", serverRecvbuf, serverCommand);
		/* dispatch command */
		switch (serverCommand) {
		case netCmdFilter:			/* set mavenNetFilter to filter mode */

			if (argString != NULL)
			{
				FILE *file;

				PRINT_DBG("netCmdFilter opening %s\n", argString);
				fopen_s(&file, argString, "r");
				if (file == NULL)
				{
					_ERROR("error: could not open %s\n", argString);
					break;
				}

				processConfigFile(file);

				/* close file */
				fclose(file);

				/* enable driver */
				(void)WinDivertEnable(windivertConfigString);
				if (driverHandle == INVALID_HANDLE_VALUE)
				{
					_ERROR("warning: failed to enable driver (%d)\n",
						GetLastError());
					/* inform admin */
				}
			}
			netState = NETFILTER_FILTER;
			PRINT_DBG("netfilter clientWorkerThread processing netCmdFilter\n");
			break;
		case netCmdIdle:			/* set mavenNetFilter to idle mode */
			PRINT_DBG("netfilter clientWorkerThread processing netCmdIdle\n");
			netState = NETFILTER_IDLE;
			WinDivertDisable(driverHandle);
			CloseHandle(driverHandle);
			driverHandle = INVALID_HANDLE_VALUE;
			PRINT_DBG("netfilter finished setting netCmdIdle\n");
			break;
		case netCmdExit:			/* exit mavenNetFilter */
			PRINT_DBG("netfilter clientWorkerThread processing netCmdExit\n");
			break;
		case netCmdStatus:			/* read status from driver and send to server */
			PRINT_DBG("netfilter clientWorkerThread processing netCmdStatus\n");
			break;
		case netCmdInvalid:			/* unable to parse */
			_ERROR("netfilter clientWorkerThread - invalid command\n");
			sprintf_s(outBuf, LINE_SIZE - 1, NETFILTER_ID_STRING " **** invalid command %s", serverRecvbuf);
			iResult = send(ConnectSocket, outBuf, (int)strlen(outBuf) + 1, 0);
			if (iResult == SOCKET_ERROR) {
				hResult = NS_E_INTERNAL_SERVER_ERROR;
				_ERROR("send failed with error: %d\n", WSAGetLastError());
			}
			break;
		}
		/* send status as response to all commands */
		QueryPerformanceCounter(&timestamp);
		/* compute elapsed time from start(seconds) */
		timePassed = (double)(timestamp.QuadPart - base.QuadPart) /
			(double)freq.QuadPart;
		PRINT_DBG("netfilter clientWorkerThread sending status\n");
		sendStatus(timePassed, pString);
	}
	return 0;
}

/***************************************************************************
* Name: metricsThresholdError
*
* Routine Description: This function computes the current event rate for
*	each filter metric and compares them with threshold settings.
*
* Returns: TRUE if any threshold is met or exceeded.
*
**************************************************************************/
BOOL metricsThresholdError(double timeElapsed)
{
	double elapsedTime = timeElapsed - metricsLastComputed;
	UINT64 metricItem, metric;

	if (elapsedTime < 1.0)
	{
		return FALSE;
	}
	metricsLastComputed = timeElapsed;

	metricItem = metrics.icmpCountInbound + metrics.icmpv6CountInbound;
	metric = metricItem - lastMetric[METRICS_ICMP_IN];
	lastMetric[METRICS_ICMP_IN] = metricItem;
	if ((metricLimits[METRICS_ICMP_IN] != 0) && 
		(metric / elapsedTime >= metricLimits[METRICS_ICMP_IN]))
	{
		PRINT_DBG("METRICS_ICMP_IN alarm\n");
		return TRUE;
	}

	metricItem = metrics.tcpCountInbound;
	metric = metricItem - lastMetric[METRICS_TCP_IN];
	lastMetric[METRICS_TCP_IN] = metricItem;
	if ((metricLimits[METRICS_TCP_IN] != 0) &&
		(metric / elapsedTime >= metricLimits[METRICS_TCP_IN]))
	{
		PRINT_DBG("METRICS_TCP_IN alarm\n");
		return TRUE;
	}

	metricItem = metrics.udpCountInbound;
	metric = metricItem - lastMetric[METRICS_UDP_IN];
	lastMetric[METRICS_UDP_IN] = metricItem;
	if ((metricLimits[METRICS_UDP_IN] != 0) &&
		(metric / elapsedTime >= metricLimits[METRICS_UDP_IN]))
	{
		PRINT_DBG("METRICS_UDP_IN alarm\n");
		return TRUE;
	}

	metricItem = metrics.icmpCountOutbound + metrics.icmpv6CountOutbound;
	metric = metricItem - lastMetric[METRICS_ICMP_OUT];
	lastMetric[METRICS_ICMP_OUT] = metricItem;
	if ((metricLimits[METRICS_ICMP_OUT] != 0) &&
		(metric / elapsedTime >= metricLimits[METRICS_ICMP_OUT]))
	{
		PRINT_DBG("METRICS_ICMP_OUT alarm\n");
		return TRUE;
	}

	metricItem = metrics.tcpCountOutbound;
	metric = metricItem - lastMetric[METRICS_TCP_OUT];
	lastMetric[METRICS_TCP_OUT] = metricItem;
	if ((metricLimits[METRICS_TCP_OUT] != 0) &&
		(metric / elapsedTime >= metricLimits[METRICS_TCP_OUT]))
	{
		PRINT_DBG("METRICS_TCP_OUT alarm\n");
		return TRUE;
	}


	metricItem = metrics.udpCountOutbound;
	metric = metricItem - lastMetric[METRICS_UDP_OUT];
	lastMetric[METRICS_UDP_OUT] = metricItem;
	if ((metricLimits[METRICS_UDP_OUT] != 0) &&
		(metric / elapsedTime >= metricLimits[METRICS_UDP_OUT]))
	{
		PRINT_DBG("METRICS_UDP_OUT alarm\n");
		return TRUE;
	}

	return FALSE;
}

/***************************************************************************
* Name: statusWorkerThread
*
* Routine Description: This thread executes at a periodic rate.  It reads
*	current metrics and reports an event if a threshold is exceeded.
*
* Returns: N/A
*
**************************************************************************/
DWORD WINAPI statusWorkerThread(LPVOID lpParam)
{
	LARGE_INTEGER base;
	LARGE_INTEGER timestamp;
	LARGE_INTEGER freq;
	double timePassed;
	double lastTimePassed = 0;
	int lastEventCount = 0;
	char OKstring[] = "    ";
	char ErrString[] = "****";
	HANDLE netDriverHandle = lpParam; /* handle to netfilter driver port */

	// Set up timing:
	QueryPerformanceFrequency(&freq);
	QueryPerformanceCounter(&base);

	PRINT_DBG("mavenNetfilter - entered statusWorkerThread \n");
	while (1)
	{		
		/* get metrics from driver */
		if ((netState != NETFILTER_IDLE) &&
			(!WinDivertGetMetrics(netDriverHandle, &metrics, sizeof(packet_metrics_t))))
		{
			_ERROR("warning: failed to read metrics from driver (%d)\n",
				GetLastError());
			/* inform admin */
		}
		else if (ConnectSocket != INVALID_SOCKET)
		{
			double lastElapsed; /* elapsed time since we last checked alarms */
			int thisEventCount; /* alarms this event period */

			QueryPerformanceCounter(&timestamp);
			/* compute elapsed time from start(seconds) */
			timePassed = (double)(timestamp.QuadPart - base.QuadPart) /
			(double)freq.QuadPart;
			char *pString = OKstring;


			lastElapsed = timePassed - lastTimePassed;
			/* if a second has passed */
			if (lastElapsed > .9)
			{
				thisEventCount = lastEventCount - eventCount;
				if (thisEventCount >= eventThreshold)
				{
					pString = ErrString;
				}
				lastEventCount = thisEventCount;
				lastTimePassed = timePassed;
			}

			/* check thresholds */
			if (metricsThresholdError(timePassed))
			{
				pString = ErrString;
			}

			sendStatus(timePassed, pString);

		}

		/* send heartbeat here */

		PRINT_DBG("statusWorkerThread delays %d \n", heartbeat);
		Sleep(heartbeat);
	}
	return 0;
}

