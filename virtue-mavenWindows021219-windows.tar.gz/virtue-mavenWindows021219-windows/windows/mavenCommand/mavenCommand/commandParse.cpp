#include "pch.h"

/* outgoing C&C JSON message fragments */
#define JSON_ENABLE "{\"enable\": "
#define JSON_GET_ENABLE "{\"get enable\": "
#define JSON_GET_CONFIG "{\"get configuration\": "
#define JSON_LIST_ENABLED "{\"list enabled\"}"
#define JSON_DISABLE "{\"disable\": "
#define JSON_NAME "{\"name\": "
#define JSON_FILEFILTER "\"fileFilter\", "
#define JSON_NETFILTER "\"netFilter\", "
#define JSON_CONFIG "\"config\" : \"%s\" "
#define JSON_CONFIG_LEARN "\"config\" : \"l\""
#define JSON_CLOSEBRACES "} }"

#define NUM_SHORTCUTS 5
#define NUM_NET_SHORTCUTS 4
static char shortcuts[NUM_SHORTCUTS] = {'i', 'f', 's', 'c', 'l' };
typedef enum _SHORTCUT
{
	idle = 0,
	filter = 1,
	status = 2,
	config = 3,
	learn = 4
}SHORTCUT;

typedef enum _COMMAND_TYPE
{
	FILEFILTER_CMD,
	NETFILTER_CMD,
	LIST_CMD,
	INVALID_CMD
} COMMAND_TYPE;
static const char * filerName[3] = { "{\"name\": \"fileFilter\"", 
 "{\"name\": \"netFilter\"", "" };

#define _ERROR(fmt,...) fprintf(stderr, "%s line %d " fmt, "mavenCommand.exe", __LINE__, __VA_ARGS__)
#define _WERROR(fmt,...) fwprintf(stderr, L"%s line %d " fmt, "mavenCommand.exe", __LINE__, __VA_ARGS__)

#define __DEBUG
#ifdef __DEBUG
#define PRINT_DBG printf
#define WPRINT_DBG wprintf
#else
#define PRINT_DBG(...)
#define WPRINT_DBG(...)
#endif

/***************************************************************************
* Name: printHelp
*
* Routine Description: This function prints a help screen.
*
* Returns:  N/A
*
**************************************************************************/
void printHelp(void)
{
	printf("mavenCommand [shortcut]  <arg(optional>\n");
	printf("sends a command to mavenWindows filters\n");
	printf("Valid Commands are:\n");
	printf("   l 		- List enabled filters\n");
	printf("   fi		- Set filefilter idle mode\n");
	printf("   ff		- Set filefilter filter mode\n");
	printf("   fl		- Set filefilter learn mode\n");
	printf("   fs		- Get filefilter enable\n");
	printf("   fc		- Get filefilter configuration\n");
	printf("   ni		- Set netfilter idle mode\n");
	printf("   nf		- Set netfilter filter mode\n");
	printf("   ns		- Get netfilter enable\n");
	printf("   nc		- Get netfilter configuration\n");
	printf("   h		- print this help screen\n");
}
/***************************************************************************
* Name: charSubstitute
*
* Routine Description: This function searches for source string for all matches
*	with a match character.  It copies characters to the destination string,
*	replacing any match with the replacement character.  If the replacemnt
*	is a backspace character ('\b'), the character is removed, making the
*	destination string shorter than the source string.
*
*	The caller must insure that the strings are long enough.
*
*	The source and destination may be the same strings.  If the backspace
*	is used for substitution however the caller must terminate the string.
*
*	If characters are deleted, the string terminator may need to be moved.
*
* Returns: length of destination string
*
**************************************************************************/
static int charSubstitute
(
	char *src,	/* source string */
	char *dest,	/* destination string */
	char matchChar,		/* character to search for */
	char replacement,	/* character to replace with */
	size_t srcLength		/* length to search */
)
{
	int i;
	int j = 0;
	for (i = 0; i < srcLength; i++)
	{
		if (src[i] != matchChar)
		{
			dest[j++] = src[i];
		}
		else if (replacement != '\b')
		{
			dest[j++] = replacement;
		}
	}
	return j;
}

/***************************************************************************
* Name: parseCommand
*
* Routine Description: This function checks to find a shortcut for the passed
*	command string.  If found, it overwrites the passed command with the 
*   full command string.
*
* Returns: N/A
*
**************************************************************************/
void parseCommand(char *commandLine)
{
	char fullCommandLine[CONSOLE_LINE_SIZE];
	size_t cmdLen;
	char *pCommandLine;
	char *pArg = NULL;
	int i;
	COMMAND_TYPE commandType = INVALID_CMD;
	int shortcut;

	/* remove any terminating '\n' from  commandLine*/
	(void)charSubstitute(commandLine, commandLine, '\n', '\0', strlen(commandLine));
	cmdLen = strlen(commandLine);

	if (cmdLen == 0)
		return; /* empty line */

	PRINT_DBG("commandLine '%s', len %d\n", commandLine, (int)cmdLen);
	/* check for one character shortcuts */
	if (cmdLen == 1) 
	{
		PRINT_DBG("one character shortcut\n");
		if (commandLine[0] == 'l')
			/* list enabled */
			commandType = LIST_CMD;
		if (commandLine[0] == 'h')
		{
			printHelp();
			commandLine[0] = '\0';
			Sleep(5000);	/* to view output */
			return;
		}
	}

	/* do we have a two character shortcut? */
	if ((cmdLen > 1) &&
		((commandLine[2] == '\0') || (commandLine[2] == ' ')))
	{
		PRINT_DBG("two character shortcut\n");
		if (commandLine[0] == 'f')
			commandType = FILEFILTER_CMD;
		if (commandLine[0] == 'n')
			commandType = NETFILTER_CMD;
	}

	if (commandType == INVALID_CMD)
	{
		PRINT_DBG("invalid command\n");
		return;
	}

	/* find command */
	for (shortcut = 0; shortcut < NUM_SHORTCUTS; shortcut++)
	{
		if (commandLine[1] == shortcuts[shortcut])
			break;
	}

	PRINT_DBG("shortcut %d\n", shortcut);
	pCommandLine = &commandLine[0];

	/* if there is an argument */
	if ((cmdLen > 4) && (commandLine[2] == ' '))
	{
		PRINT_DBG("argument found\n");
		for (i = 2; i < cmdLen; i++)
			if (!isspace(commandLine[i]))
				break;
		if ((commandLine[i] != '\0') && (commandLine[i] != '\n'))
		{
			pArg = &commandLine[i];
			PRINT_DBG("argument %s\n", pArg);

		}

	}

	if (commandType == LIST_CMD)
		snprintf(fullCommandLine, CONSOLE_LINE_SIZE, JSON_LIST_ENABLED);

	else switch (shortcut)
	{
	case idle:
		snprintf(fullCommandLine, CONSOLE_LINE_SIZE, JSON_DISABLE " %s" JSON_CLOSEBRACES,
			filerName[commandType]);
		break;
	case filter:
		if (pArg)
		{
			snprintf(fullCommandLine, CONSOLE_LINE_SIZE, JSON_ENABLE " %s, " JSON_CONFIG JSON_CLOSEBRACES,
				filerName[commandType], pArg);
		}
		else
			snprintf(fullCommandLine, CONSOLE_LINE_SIZE, JSON_ENABLE " %s" JSON_CLOSEBRACES,
				filerName[commandType]);
		break;
	case status:
		snprintf(fullCommandLine, CONSOLE_LINE_SIZE, JSON_GET_ENABLE " %s" JSON_CLOSEBRACES,
			filerName[commandType]);
		break;
	case config:
		snprintf(fullCommandLine, CONSOLE_LINE_SIZE, JSON_GET_CONFIG " %s" JSON_CLOSEBRACES,
			filerName[commandType]);
		break;
	case learn:
		snprintf(fullCommandLine, CONSOLE_LINE_SIZE, JSON_DISABLE " %s, " JSON_CONFIG_LEARN JSON_CLOSEBRACES,
			filerName[commandType]);
		break;
	default:
		return;
	}

	snprintf(commandLine, CONSOLE_LINE_SIZE, fullCommandLine);

}