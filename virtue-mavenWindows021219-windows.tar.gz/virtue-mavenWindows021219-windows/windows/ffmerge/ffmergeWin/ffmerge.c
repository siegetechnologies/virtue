/*++

Module Name: ffmergeWin.cpp

Abstract:
This utility combines two or more maven filefilter configuration whitelist files to construct
a new configuration file that has merged entries.

The utility will build as either a windows or linux executable.  To build for
linux, use the makefile in this directory on a linux build machine.

Revision History:
Author Richard Carter - Siege Technologies, Manchester NH

V1.0	10/23/2018	- REC, original
V1.1	11/07/2018	- REC, add -f option
--*/
/* Copyright(c) 2019 Siege Technologies, 1105 Floyd Avenue Rome, NY 13440

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files(the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions :

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/
#ifdef _WIN32
#define _CRT_SECURE_NO_WARNINGS
#include <windows.h>
#include "..\..\include\maven.h"
#define _ERROR(fmt,...) fprintf(stderr, "%s line %d " fmt, __FILE__, __LINE__, __VA_ARGS__)
#else
#define MAX_PATH 260
#ifndef FALSE
#define FALSE               0
#endif

#ifndef TRUE
#define TRUE                1
#endif

typedef unsigned int DWORD32;
typedef int BOOL;
#include <string.h>
#include <stddef.h>
#include <stdlib.h>
#include "../../include/maven.h"
#define _ERROR(...) fprintf(stderr, __VA_ARGS__)
#endif
#include <stdio.h>
#include <ctype.h>

#undef __DBG
#ifdef __DBG
#define PRINT_DBG(...) printf(__VA_ARGS__)
#else
#define PRINT_DBG(...)
#endif

#define MAX_CONFIG_STRING (MAX_PATH + 20)

/***************************************************************************
* Name: entryMerge
*
* Routine Description: This function merges two configuration entries.  It
*    updates the input entry extension list to include the merge entry
*    extensions. If there is insufficient room, it zeros the input entry
*    list and inserts a wildcard.
*
* Returns:  N/A.
*
**************************************************************************/
void entryMerge
(
	MAVEN_FILFILTER_RECORD *pInputEntry, 
	MAVEN_FILFILTER_RECORD *pMergeEntry
)
{
	int mergeIndex, inputIndex;


	/* here the paths match. Merge the extension lists */
	/* first check for a wild-card */
	if (pInputEntry->extensions[0][0] == '*')
	{
		/* input list entry already full */
		return;
	}
	if (pMergeEntry->extensions[0][0] == '*')
	{
		/* extensions list entry already full */
		/* mark input extensions list as being full */
		memset(pInputEntry->extensions, 0, sizeof(pInputEntry->extensions));
		pInputEntry->extensions[0][0] = '*';
		return;
	}

	for (mergeIndex = 0; mergeIndex < MAVEN_MAX_EXT_ENTRIES; mergeIndex++)
	{
		BOOL stringFound = FALSE;
		/* if end of merge extensions list */
		if (pMergeEntry->extensions[mergeIndex][0] == '\0')
		{
			break; /* done */
		}
		/* see if extension is already listed */
		for (inputIndex = 0; inputIndex < MAVEN_MAX_EXT_ENTRIES; inputIndex++)
		{
			if (pInputEntry->extensions[inputIndex][0] == '\0')
				break;
			stringFound = (strncmp(&pMergeEntry->extensions[mergeIndex][0],
				&pInputEntry->extensions[inputIndex][0], MAVEN_MAX_EXT_LENGTH) == 0);
			if (stringFound)
			{
				/* string match found, stop searching */
				break;
			}
		}
		if (stringFound)
		{
			/* string match found, move on to next merge extension */
			continue;
		}
		/* string not found, must be added */
		/* first make sure there is room */
		if (inputIndex == MAVEN_MAX_EXT_ENTRIES)
		{
			/* no room */
			/* mark input extensions list as being full */
			memset(pInputEntry->extensions, 0, sizeof(pInputEntry->extensions));
			pInputEntry->extensions[0][0] = '*';
			return;
		}
		/* room, so add new entry */
		memcpy(&pInputEntry->extensions[inputIndex][0], &pMergeEntry->extensions[mergeIndex][0], EXTENSION_LENGHT);
		continue;	/* next merge extension */
		
	}
}

/***************************************************************************
* Name: listSearch
*
* Routine Description: This function searches an input list for a record
*    with a matching process image name. 
*
* Returns:  Pointer to matching record or NULL if not found.
*
**************************************************************************/
MAVEN_FILFILTER_RECORD *listSearch
(
	MAVEN_FILFILTER_RECORD *pInputList, 
	MAVEN_FILFILTER_RECORD *pEntry,
	BOOL checkExtensions
)
{
	MAVEN_FILFILTER_RECORD *pInputListEntry = pInputList;
	int i;

	/* search for matching path */
	while (pInputListEntry != NULL)
	{
		if (strncmp(pInputListEntry->processImageName, pEntry->processImageName, MAX_PATH) == 0)
		{
			break;	/* match found */
		}
		pInputListEntry = pInputListEntry->next;
	}
	if ((pInputListEntry != NULL) && (checkExtensions))
	{
		/* match extension list too */
		for (i = 0; i < MAVEN_MAX_EXT_ENTRIES; i++)
		{
			if ((pInputListEntry->extensions[i][0] == 0) && (pEntry->extensions[i][0] == 0))
			{
				return pInputListEntry;
			}
			if (strncmp(&pInputListEntry->extensions[i][0], &pEntry->extensions[i][0], EXTENSION_LENGHT) != 0)
			{
				PRINT_DBG("listSearch new extension %s\n", pEntry->extensions[i]);

				return NULL; /* mismatch */
			}
		}
	}
	return pInputListEntry;
}

/***************************************************************************
* Name: listMerge
*
* Routine Description: This function merges two configuration lists.  It
*    searches the input list for a match with the process image name found
*    in each record of the merge list.  If it finds a match, it updates
*    the extension list to add any new extensions.  If no match is found
*    it adds a new entry to the end of the input list.
*
* Returns:  N/A.
*
**************************************************************************/
void listMerge
(
	MAVEN_FILFILTER_RECORD *pInputList, 
	MAVEN_FILFILTER_RECORD *pAddList
)
{
	MAVEN_FILFILTER_RECORD *pAddListEntry = pAddList;
	MAVEN_FILFILTER_RECORD *pLastEntry = NULL;
	MAVEN_FILFILTER_RECORD *pInputListLastEntry = pInputList;
	MAVEN_FILFILTER_RECORD *pMatchingEntry;
	MAVEN_FILFILTER_RECORD *pEntry;

	/* first, find end of input list */
	while ((pInputListLastEntry != NULL) && (pInputListLastEntry->next != NULL))
	{
		pInputListLastEntry = pInputListLastEntry->next;
	}

	while (pAddListEntry != NULL)
	{
		pMatchingEntry = listSearch(pInputList, pAddListEntry, FALSE);
		if (pMatchingEntry != NULL)
		{
			entryMerge(pMatchingEntry, pAddListEntry);
			pLastEntry = pAddListEntry;
			pAddListEntry = pAddListEntry->next;
			continue;
		}
		else
		{
			/* copy entry */
			pEntry = (MAVEN_FILFILTER_RECORD *)malloc(sizeof(MAVEN_FILFILTER_RECORD));
			if (pEntry == NULL)
			{
				_ERROR("unable to allocate buffer\n");
				return;
			}
			/* copy record to new entry */
			memcpy(pEntry, pAddListEntry, sizeof(MAVEN_FILFILTER_RECORD));
			pEntry->next = NULL;	 /* mark as end of list */

			/* add entry to end of list */

			pInputListLastEntry->next = pEntry;
			pInputListLastEntry = pEntry;
			pAddListEntry = pAddListEntry->next;
		}
	}
}

/***************************************************************************
* Name: listSplit
*
* Routine Description: This compares two lists and generates a new list that
*	has entries for the differene.
*	The base list is assumed to be a minimal list needed to boot the board.
*	The role list is assumed to be the base list plus entries for a new app(s).
*
* Returns:  A list pointer to whatever is needed to modify the base list to
*	support the new app(s).
*
**************************************************************************/
MAVEN_FILFILTER_RECORD * listSplit
(
	MAVEN_FILFILTER_RECORD *pRoleList,
	MAVEN_FILFILTER_RECORD *pBaseList
)
{
	MAVEN_FILFILTER_RECORD *pRoleListEntry = pRoleList;
	MAVEN_FILFILTER_RECORD *pBaseListEntry = pBaseList;
	MAVEN_FILFILTER_RECORD *pEntry = NULL;
	MAVEN_FILFILTER_RECORD *pOutputList = NULL;
	MAVEN_FILFILTER_RECORD *pOutputListEntry = NULL;

	pRoleListEntry = pRoleList;
	/* iterate through the role list (larger of two) */
	while (pRoleListEntry != NULL)
	{
		/* if the role entry is not in the base list */
		if (listSearch(pBaseList, pRoleListEntry, TRUE) == NULL)
		{
			PRINT_DBG("listSplit adding %s\n", pRoleListEntry->processImageName);
			/* copy role list entry to output list */
			pEntry = (MAVEN_FILFILTER_RECORD *)malloc(sizeof(MAVEN_FILFILTER_RECORD));
			if (pEntry == NULL)
			{
				_ERROR("unable to allocate buffer\n");
				return pOutputList;
			}
			/* copy record to new entry */
			memcpy(pEntry, pRoleListEntry, sizeof(MAVEN_FILFILTER_RECORD));
			pEntry->next = NULL;	 /* mark as end of list */
			if (pOutputList == NULL) /* if first entry */
			{
				pOutputList = pEntry; /* set list pointer to point to this entry */
				pOutputListEntry = pEntry;
			}
			else
			{
				pOutputListEntry->next = pEntry; /* link pointer */
				pOutputListEntry = pEntry; /* point to next entry */
			}
		}
		pRoleListEntry = pRoleListEntry->next; /* next element in role list */
	}
	return pOutputList;
}

/***************************************************************************
* Name: printConfigFile
*
* Routine Description: This function prints the configuration file to the
*    passed file descriptor.
*
* Returns:  number of entries printed
*
**************************************************************************/
int printConfigFile(
	FILE *fptr, 
	MAVEN_FILFILTER_RECORD *list
)
{
	MAVEN_FILFILTER_RECORD *pEntry = list;
	int i;
	int numEntries = 0;
	while (pEntry != NULL)
	{
		PRINT_DBG("(%p) %s\t1\t0",fptr, pEntry->processImageName);
		fprintf(fptr, "%s\t1\t0", pEntry->processImageName);
		for (i = 0; i < MAVEN_MAX_EXT_ENTRIES; i++)
		{
			if (pEntry->extensions[i][0] == '\0')
				break;
			PRINT_DBG("\t%s", &pEntry->extensions[i][0]);
			fprintf(fptr, "\t%s", &pEntry->extensions[i][0]);
		}
		PRINT_DBG("\n");
		fprintf(fptr, "\n");
		pEntry = pEntry->next;
		numEntries++;
	}
	return numEntries;
}

/***************************************************************************
* Name: readConfigFile
*
* Routine Description: This function reads a configuration file and parses 
*    each entry to form a representation of the file in memory.
*
* Returns:  Pointer to last record created or NULL if error
*
**************************************************************************/
MAVEN_FILFILTER_RECORD *readConfigFile(
	FILE *fptr, 
	MAVEN_FILFILTER_RECORD **listHead, 
	char *configString
)
{
	int numEntries = 0;
	char inbuf[MAVEN_FILFILTER_RECORD_SZ];
	MAVEN_FILFILTER_RECORD *pEntry = NULL;
	MAVEN_FILFILTER_RECORD *pLastEntry = NULL;

	/* read file and copy fields to list
	 *
	 * returns number of records read
	 */
	PRINT_DBG("readConfigFile %p\n", fptr);
	while (fgets(inbuf, MAVEN_FILFILTER_RECORD_SZ, fptr))
	{
		int i = 0;
		int j;
		int extensionIndex = 0;

		PRINT_DBG("read %s\n", inbuf);
		/* if the record is the first configuration string */
		if ((configString[0] == '\0') && (inbuf[0] == CONFIURATION_KEY))
		{
			/* save it off */
			PRINT_DBG(">> configString %s\n", inbuf);
			strncpy(configString, inbuf, MAX_CONFIG_STRING);
			continue;
		}

		/* find lenth of path */
		while ((i < MAVEN_FILFILTER_RECORD_SZ) && (inbuf[i] != '\0') && (inbuf[i] != '\t'))
			i++;

		PRINT_DBG("pathlen=%d\n", i);
		/* if we have a valid record */
		if ((i > 0) && (inbuf[0] == '\\'))
		{
			if (pEntry == NULL)
			{
				pEntry = (MAVEN_FILFILTER_RECORD *)malloc(sizeof(MAVEN_FILFILTER_RECORD));
			}
			if (pEntry == NULL)
			{
				_ERROR("unable to allocate buffer\n");
				return NULL;
			}
			memset(pEntry, 0, sizeof(MAVEN_FILFILTER_RECORD));
			if (*listHead == NULL)
			{
				*listHead = pEntry;	/* first entry in list */
			}
			else
			{
				if (pLastEntry == NULL)
				{
					pLastEntry = *listHead;
				}
				pLastEntry->next = pEntry;
			}

			/* point to new record */
			pLastEntry = pEntry;
			/* copy the record to the list entry */
			memcpy(pEntry->processImageName, inbuf, i);
			pEntry->processImageName[i] = '\0';	/* terminate */
			numEntries++;
		}
		else
		{
			continue; /* not a valid record */
			PRINT_DBG("INV %d %s\n", i, inbuf);
		}

		/* advance past the count and fail fields (not used) */
		i++;
		while ((i < MAVEN_FILFILTER_RECORD_SZ) && (inbuf[i] != '\0') && (inbuf[i] != '\t'))
			i++;
		if (inbuf[i] != '\0')
			i++;	/* advance past tab */
		while ((i < MAVEN_FILFILTER_RECORD_SZ) && (inbuf[i] != '\0') && (inbuf[i] != '\t'))
			i++;
		if (inbuf[i] != '\0')
			i++;	/* advance past tab */
		/* anything left in the string is extensions (optional) */
		while ((i < MAVEN_FILFILTER_RECORD_SZ) && (inbuf[i] != '\0') && (extensionIndex < MAVEN_MAX_EXT_ENTRIES))
		{
			j = 0;
			/* copy extension field to next extension slot */
			while ((i < MAVEN_FILFILTER_RECORD_SZ) && (inbuf[i] != '\0') &&
				(j < MAVEN_MAX_EXT_LENGTH) && (inbuf[i] != '\t') && (inbuf[i] != '\n'))
			{
				pEntry->extensions[extensionIndex][j++] = inbuf[i++];
			}
			pEntry->extensions[extensionIndex++][j++] = 0; /* terminate extension */
			if ((inbuf[i] == '\t') || (inbuf[i] == '\n'))
				i++;	/* advance past tab to next field*/
		}
		pEntry = NULL;

	} /* end while read file and copy fields to list*/
return pLastEntry;
}

/***************************************************************************
* Name: listFree
*
* Routine Description: This function frees all entries on a list.
*
* Returns:  N/A.
*
**************************************************************************/
void listFree(MAVEN_FILFILTER_RECORD *pEntry)
{
	while (pEntry != NULL)
	{
		MAVEN_FILFILTER_RECORD *pNextEntry = pEntry->next;
		free(pEntry);
		pEntry = pNextEntry;
	}
}

/***************************************************************************
* Name: printHelp
*
* Routine Description: This prints the help page.
*
* Returns:  N/A.
*
**************************************************************************/
void printHelp(void)
{
printf("Usage: ffmerge [options] file...\n");
printf("Options:\n");
printf("   -h		Print help\n");
printf("   -s		Split files\n");
printf("   -l		Set Learn Mode (case insensitive)\n");
printf("   -i		Set Idle Mode (case insensitive)\n");
printf("   -f		Set Filter Mode (case insensitive)\n");
printf("Description: This utility merges two or more maven filefilter configuration files"
	" into a new configuration file that contains the merged output.  The"
	" first filter configuration line found in the input files is copied"
	" to the output file. \n"
	" The first configuration line found in the input string(s) is copied to"
	" the output file. The fileFilter operating mode may optionally be overridden"
	" using the -l, -i, or -f command line options\n"
	"    usage: ffmerge baseFile outputFile additionFile...\n\n");
printf("When used with the -s option, the utility splits two files and"
	" forms an output file that is the difference of the two input files\n"
	"    usage: ffmerge -s completeFile outputFile baseFile...\n\n");
printf("Examples:\n"
	"to create role.txt from baseline.txt + calculator.txt + calendar.txt\n"
	"	> ffmerge baseline.txt role.txt calculator.txt calendar.txt\n"
	"to create fragment calculator.txt from baselineCalculator.txt - baseline.txt\n"
	"	> ffmerge -s baselinneCalculator.txt calculator.txt baseline.txt\n");

}


/***************************************************************************
* Name: overrideMode
*
* Routine Description: This function searches for the mode string in the
*	file filter configuration line.  It replaces the mode with the passed
*	character.
*
* Returns:  zero if successful, otherwise passed mode
*
**************************************************************************/

char overrideMode(char *configString, char mode)
{
	char *pStr;
	/* overwrite filter mode and set to learn */
	pStr = strstr(configString, "mode");
	if (pStr != NULL)
	{
		/* advance past search key */
		pStr += strlen("mode");
		/* Advance through field until we find '=' */
		while ((*pStr != '\0')&& (*pStr != '=') && 
			(*pStr != ',') && (*pStr != ';') && (*pStr != '\n'))
		{
			pStr++;
		}
		/* should now point to '=' */
		if (*pStr == '=')
		{
			pStr++;
			/* advance past spaces */
			while ((*pStr != '\0') && !isalpha(*pStr) &&
				(*pStr != ',') && (*pStr != ';') && (*pStr != '\n'))
			{
				pStr++;
			}
			/* should now point to first character of mode */
			if (isalpha(*pStr))
			{
				*pStr++ = mode;	/* override mode */
			}
			else
			{
				return mode;	/* mode not found */
			}

			/* now pointing at next character in mode field.  clear from here to comma */
			while ((*pStr != '\0') && (*pStr != ',') && (*pStr != '\n') && (*pStr != ',') 
				&& (*pStr != ';') && isalpha(*pStr))
			{
				*pStr++ = ' ';
			}
			return 0;
		}
	}
	return mode;
}


/***************************************************************************
* Name: Main
*
* Routine Description: This function is the entry point for the command line
*   utility.
*
* Returns:  N/A.
*
**************************************************************************/
int main(int argc, const char *argv[])
{
	int i;
	int minNumArgs = 4;
	int firstFilename = 1;
	int retVal = 0;
	BOOL splitFiles = FALSE;
	char setMode = 0;
	char configString[MAX_CONFIG_STRING] = { 0 };
	MAVEN_FILFILTER_RECORD *pInputList = NULL;
	MAVEN_FILFILTER_RECORD *pMergeList = NULL;
	MAVEN_FILFILTER_RECORD *pOutputList = NULL;
	MAVEN_FILFILTER_RECORD *pEntry = NULL;
	MAVEN_FILFILTER_RECORD *pNextEntry = NULL;

	FILE *srcFile = NULL;
	FILE *destFile = NULL;
	FILE *mergeFile = NULL;

	if ((argc > 1) && (argv[1][0] == '-'))
	{
		if ((argv[1][1] == 'h') || (argv[1][1] == '-') && (argv[1][2] == 'h'))
		{
			printHelp();
			return 0;
		}

		if (argv[1][1] == 's')
		{
			if (argc != 5)
			{
				_ERROR("wrong number of arguments\n");
				return -1;
			}
			splitFiles = TRUE;
			firstFilename = 2;
		}
		if ((argv[1][1] == 'l') || (argv[1][1] == 'L') || (argv[1][1] == 'i') || 
			(argv[1][1] == 'I') || (argv[1][1] == 'f') || (argv[1][1] == 'F'))
		{
			if (argc < 4)
			{
				_ERROR("wrong number of arguments\n");
				return -1;
			}
			setMode = argv[1][1];
			firstFilename = 2;
			minNumArgs++;
		}
	}
	if (argc < minNumArgs)
	{
		_ERROR("wrong number of arguments\n");
		return -1;
	}

	PRINT_DBG("opening %s\n", argv[1]);
	srcFile = fopen(argv[firstFilename + 0], "r");
	if (!srcFile)
	{
		_ERROR("unable to open source file %s\n", argv[1]);
		retVal = -1;
		goto cleanp;
	}
	/* copy the input file to local memory */
	pNextEntry = readConfigFile(srcFile, &pInputList, configString);
	if (pNextEntry == NULL)
	{
		_ERROR("unable to read source file %s\n", argv[1]);
		retVal = -1;
		goto cleanp;
	}

	/* if there was a passed argument to set learn mode */
	if ((setMode != 0) && (configString[0] == CONFIURATION_KEY))
	{
		setMode = overrideMode(configString, setMode);
	}

	PRINT_DBG("pInputList(%p) printed %d entries\n", srcFile, printConfigFile(stdout, pInputList));
	PRINT_DBG("opening %s\n", argv[2]);
	destFile = fopen(argv[firstFilename + 1], "w");
	if (!destFile)
	{
		_ERROR("unable to open destination file %s\n", argv[2]);
		retVal = -1;
		goto cleanp;
	}

	pNextEntry = pMergeList;	/* start reading add list entries */
	for (i = firstFilename + 2; i < argc; i++)
	{
		PRINT_DBG("opening %s\n", argv[i]);
		mergeFile = fopen(argv[i], "r");
		PRINT_DBG("mergeFile %s = %p\n", argv[i], mergeFile);
		if (!mergeFile)
		{
			_ERROR("unable to open file %s\n", argv[i]);
			retVal = -1;
			goto cleanp;
		}

		/* copy the input file to local memory, adding to list end in subsequent reads */
		pNextEntry = readConfigFile(mergeFile, (pMergeList == NULL)? &pMergeList : &pNextEntry, configString);

		if (pNextEntry == NULL)
		{
			_ERROR("unable to read file %s\n", argv[i]);
			retVal = -1;
			goto cleanp;
		}
		fclose(mergeFile);
	}
	PRINT_DBG("pMergeList(%p) printed %d entries\n", mergeFile, printConfigFile(stdout, pMergeList));

	if (splitFiles)
	{
		/* split lists */
		pOutputList = listSplit(pInputList, pMergeList);
	}
	else
	{
		/* merge lists */
		listMerge(pInputList, pMergeList);
		pOutputList = pInputList; /* using input list for output list buffer */
		pInputList = NULL; /* don't use this pointer for cleanup */
	}

	/* write local copy to file */
	fprintf(destFile, "%s", configString);
	PRINT_DBG("(%p) printed %d entries\n", destFile, printConfigFile(stdout, pOutputList));
	(void)printConfigFile(destFile, pOutputList);
cleanp:
	if (srcFile)
		fclose(srcFile);
	if (destFile)
		fclose(destFile);
	listFree(pInputList);
	listFree(pMergeList);
	listFree(pOutputList);
	return retVal;
}

